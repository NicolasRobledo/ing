
## Trabajo Practico N°2
## 1. Describa y ejemplifique los diferentes tipos de planes.

Los planes son herramientas fundamentales en la administración para alcanzar los objetivos organizacionales. Se clasifican en:

- **Misiones o propósitos**: Identifican la función básica de una organización.  
	- def: La misión o propósito (términos que se utilizan indistintamente) identifica las funciones o tareas básicas de una empresa, dependencia o cualquiera de sus partes.
    _Ejemplo_: La misión de Google es "organizar la información del mundo y hacerla accesible y útil para todos".
    
- **Objetivos o metas**: Son los fines hacia los cuales se dirige la actividad.  
	- def: Los objetivos son los fines hacia los cuales se dirige la actividad y representan el punto final de la planeación, organización, integración de personal, dirección y control.
    _Ejemplo_: Lograr un rendimiento sobre la inversión del 12% al final del año fiscal.
    
- **Estrategias**: Forma en que se determinan los objetivos a largo plazo. 
	- Las estrategias son la determinación de objetivos a largo plazo, el establecimiento de acciones y la asignación de recursos necesarios para alcanzarlos.
    _Ejemplo_: Una empresa adopta una estrategia de diferenciación para destacar sus productos.
    
- **Políticas**: Criterios generales que orientan la toma de decisiones.  
	- def: Consisten en enunciados o criterios generales que orientan y encauzan el pensamiento en la toma de decisiones.
	   Las políticas definen un área dentro de la cual debe tomarse una decisión y aseguran que ésta sea consistente con un objetivo y contribuya a su logro. Las políticas ayudan a solucionar problemas antes de que se vuelvan serios, hacen innecesario analizar la misma situación cada vez que se presenta y unifican otros planes.
    _Ejemplo_: Política de contratación exclusiva de profesionales.
    
- **Procedimientos**: Secuencias cronológicas de acciones requeridas. 
	- def: Establecen un método para el manejo de actividades futuras. Consisten en secuencias cronológicas de las acciones requeridas.
		Son guías de acción, no de pensamiento, en las que se detalla la manera exacta en que deben realizarse ciertas actividades.
    _Ejemplo_: Procedimiento para solicitar vacaciones en una empresa.
    
- **Reglas**: Acciones específicas no sujetas a discrecionalidad. 
    _Ejemplo_: "No fumar" en áreas designadas.
    
- **Programas**: Conjunto de metas, políticas y recursos para un curso de acción.  
    _Ejemplo_: Programa de lanzamiento de un nuevo producto.
    
- **Presupuestos**: Resultados esperados en términos numéricos.  
    _Ejemplo_: Presupuesto de gastos operativos para el próximo trimestre.


## 2. Describa y grafique los pasos de la planeación.

Los pasos de la planeación son:

1. **Atención a las oportunidades**: Identificar oportunidades y amenazas en el entorno.
    
2. **Establecimiento de objetivos**: Definir metas claras y alcanzables.
    
3. **Consideración de premisas**: Suposiciones sobre el ambiente futuro.
    
4. **Identificación de alternativas**: Buscar cursos de acción posibles.
    
5. **Comparación de alternativas**: Evaluar opciones en función de las metas.
    
6. **Elección de una alternativa**: Seleccionar la mejor opción.
    
7. **Formulación de planes de apoyo**: Desarrollar planes complementarios.
    
8. **Conversión en presupuestos**: Cuantificar los planes.

![[Pasted image 20250521141910.png]]

## 5. Describa y grafique los conceptos en evolución de la administración por objetivos, y sus ventajas y debilidades.

**Administración por Objetivos (APO)**: Sistema que integra actividades gerenciales para lograr objetivos organizacionales e individuales.

**Ventajas**:

- Mejora la administración mediante planeación orientada a resultados.
    
- Facilita la delegación de autoridad.
    
- Fomenta el compromiso con las metas.
    
- Desarrolla controles efectivos.
    

**Debilidades**:

- Falta de enseñanza de la filosofía APO.
    
- Dificultad para establecer metas verificables.
    
- Enfoque excesivo en metas a corto plazo.

![[Pasted image 20250521143912.png]]

## 6. Describa y grafique el proceso de planeación estratégica.

**Proceso**:

1. **Insumos**: Humanos, capital, administrativos, tecnológicos.
    
2. **Orientación ejecutiva**: Valores y visión.
    
3. **Análisis de la industria**: Perfil empresarial y fuerzas competitivas.
    
4. **Propósito**: Misión, objetivos principales.
    
5. **Análisis FODA**: Fortalezas, debilidades, oportunidades, amenazas.
    
6. **Desarrollo de estrategias alternativas**: Evaluación y decisión.
    
7. **Instrumentación**: Planes a mediano y corto plazo.
    
8. **Control**: Revisión y ajustes.

![[Pasted image 20250521143959.png]]
## 7. Describa y grafique el concepto de matriz FODA y desarrolle las cuatro estrategias alternativas.

**Matriz FODA**: Herramienta para analizar fortalezas (F), debilidades (D), oportunidades (O) y amenazas (A).

**Estrategias alternativas**:

1. **FO (Maxi-Maxi)**: Aprovechar fortalezas para oportunidades.
    
2. **FA (Maxi-Mini)**: Usar fortalezas para minimizar amenazas.
    
3. **DO (Mini-Maxi)**: Superar debilidades para aprovechar oportunidades.
    
4. **DA (Mini-Mini)**: Minimizar debilidades y amenazas (ej.: reducción o liquidación).
![[Pasted image 20250521144445.png]]

## 9. Describa y grafique la Matriz de portafolio: una herramienta para asignar recursos.

**Matriz de Portafolio (BCG)**: Clasifica negocios según crecimiento y participación de mercado.

- **Estrellas**: Alta participación y crecimiento (inversión).
    
- **Vacas de liquidez**: Alta participación, bajo crecimiento (generan efectivo).
    
- **Interrogantes**: Baja participación, alto crecimiento (evaluar potencial).
    
- **Perros**: Baja participación y crecimiento (evitar o liquidar).
![[Pasted image 20250521144529.png]]

## 12. Describa y grafique el análisis de la industria (Las 5 fuerzas de Porter) y estrategias competitivas genéricas de Porter.

**Cinco fuerzas de Porter**:

1. Competencia entre compañías.
    
2. Amenaza de nuevos competidores.
    
3. Productos sustitutos.
    
4. Poder de negociación de proveedores.
    
5. Poder de negociación de clientes.
		def: Una empresa puede adoptar estrategias genéricas basadas en el análisis de la industria. Estas estrategias se ajustan a diferentes tipos de organizaciones, aunque una empresa puede usar más de una estrategia.
    

**Estrategias genéricas**:

- **Liderazgo en costos**: Reducción de costos para competir.
	- def: Este enfoque estratégico busca la reducción de costos, basado en la experiencia. La importancia radica en mantener una vigilancia estrecha de los costos en áreas como investigación y desarrollo, operación, ventas y servicio. El objetivo es que una compañía tenga una estructura de bajo costo comparada con sus competidores. Esta estrategia a menudo requiere una participación de mercado relativamente grande y una operación eficiente en costos.
    
- **Diferenciación**: Ofrecer algo único.
	- def: La compañía que sigue una estrategia de diferenciación intenta ofrecer algo único en la industria en términos de productos o servicios.
    
- **Enfoque**: Concentrarse en un segmento específico.
	- def: Al atender a todo el mercado con sus productos o servicios, una empresa puede enfocarse en un segmento específico del mercado. En general, una compañía debe elegir una estrategia genérica para "no verse atrapada en el centro"

![[Pasted image 20250521145025.png]]


## 13. Describa y grafique el concepto de cadena de valor. Describa el concepto de sistema de información en la empresa.

**Cadena de Valor**: Actividades que agregan valor al producto:

- **Primarias**: Logística, operaciones, marketing, servicio.
    
- **De apoyo**: Infraestructura, RRHH, tecnología, compras.
    

**Sistema de Información**: Procesos que recopilan, elaboran y distribuyen información para operar y tomar decisiones.
![[Pasted image 20250521150105.png]]
Segunda Definicion:
La Cadena de Valor se divide en actividades básicas o primarias y actividades de soporte o apoyo. Cada actividad agrega valor al producto.

 Las **actividades primarias** están relacionadas con la creación física del producto, su marketing y distribución a los compradores, junto con su apoyo y servicio de postventa.

Las **actividades de apoyo** son las tareas funcionales que permiten llevar a cabo las actividades primarias de fabricación y marketing.

## 14. Describa: la importancia y limitaciones de la toma de decisiones racional; el desarrollo de alternativas y el factor limitante; evaluación de alternativas; y los tres enfoques para la selección de una alternativa.

**Importancia**: Permite elegir la mejor opción para alcanzar objetivos.  
**Limitaciones**: Información incompleta, tiempo limitado, certidumbre.

**Desarrollo de alternativas**: Identificar opciones viables.  
**Factor limitante**: Obstáculo que afecta la decisión.

**Evaluación de alternativas**: Comparar en función de metas.

**Enfoques para selección**:

1. **Experiencia**: Basada en conocimientos previos.
    
2. **Experimentación**: Probar alternativas.
    
3. **Investigación y análisis**: Uso de datos y modelos.

![[Pasted image 20250521150350.png]]
extension:
**Evaluación de alternativas. Factores cuantitativos y cualitativos:**
Al comparar planes para alcanzar un objetivo, a menudo se piensan en **factores cuantitativos** como el tiempo y los costos. Aunque este análisis es esencial, el éxito del proyecto podría estar en riesgo si se ignoran los **factores cualitativos**, como la calidad de las relaciones laborales, el riesgo de cambios tecnológicos o el clima político internacional.
Para evaluar y comparar los factores intangibles en la toma de decisiones, **los gerentes deben identificar dichos factores, determinar si se les puede asignar una medida cuantitativa razonable** y, de no ser así, investigar a fondo estos factores. Luego deben calificarlos según su importancia, comparar su influencia probable con la de los factores cuantitativos y tomar una decisión que puede dar mayor peso a un solo intangible.
## 15. Describa y grafique las decisiones programadas y no programadas.

**Decisiones programadas**: Rutinarias, basadas en reglas.  
_Ejemplo_: Reprocesar un producto defectuoso según especificaciones.

**Decisiones no programadas**: No estructuradas, requieren juicio.  
_Ejemplo_: Lanzar un nuevo producto en un mercado emergente.
![[Pasted image 20250521151005.png]]
definicion 2:
Una **decisión programada** se aplica a problemas estructurados o rutinarios Este tipo de decisión se usa en trabajos rutinarios y repetitivos, basados en criterios preestablecidos.

Las **decisiones no programadas** se emplean en situaciones no estructuradas, nuevas o mal definidas. Generalmente, las decisiones estratégicas son no programadas, derivadas de juicios subjetivos.

La mayoría de las decisiones son una combinación de decisiones programadas y no programadas.
## 16. Describa la toma de decisiones en condiciones de certidumbre, incertidumbre y riesgo.

- **Certidumbre**: Información confiable y resultados predecibles.
    
- **Incertidumbre**: Falta de información, resultados desconocidos.
    
- **Riesgo**: Información parcial, probabilidades estimadas.
    

_Ejemplo_:

- **Certidumbre**: Inversión con rendimiento fijo.
    
- **Riesgo**: Lanzamiento de producto con probabilidad de éxito.
    
- **Incertidumbre**: Expansión a un mercado desconocido.

## Trabajo Practico N°3

#### **1. Explique en qué consiste la organización formal y la informal. Grafique.**

**Organización Formal:**  
Es la estructura intencional y jerárquica de una empresa, diseñada para lograr objetivos específicos. Se basa en roles, normas, y relaciones definidas oficialmente (como organigramas). Ejemplo: departamentos de ventas, producción, o finanzas.

**Organización Informal:**  
Surge espontáneamente de las interacciones sociales entre los miembros de la organización. No está planificada y se basa en relaciones personales, como grupos de café o equipos deportivos.
![[Pasted image 20250521152718.png]]
definicion 2: 
**Organización Formal:**

 Es la estructura intencional de funciones en una empresa formalmente organizada.

**Organización Informal:**

Es una red de relaciones personales y sociales no establecida ni requerida por la organización formal, pero que surge espontáneamente de la asociación entre sí de las personas.

#### **2. ¿En qué consiste la división organizacional? Describa las organizaciones con ámbitos estrechos y amplios. Explique los factores que determinan un ámbito efectivo.**

**División Organizacional:**  
Es la agrupación de actividades en departamentos o unidades (ej: ventas, producción) para especializar funciones y mejorar la eficiencia.

**Ámbitos Estrechos (Estructura Piramidal):**
![[Pasted image 20250521153502.png]]

- **Ventajas:** Control riguroso, comunicación rápida.
    
- **Desventajas:** Muchos niveles jerárquicos, costos elevados.
    

**Ámbitos Amplios (Estructura Plana):**
![[Pasted image 20250521153847.png]]
- **Ventajas:** Delegación clara, menos niveles.
    
- **Desventajas:** Riesgo de sobrecarga de supervisores.
    

**Factores para un Ámbito Efectivo:**

- Capacitación de subordinados.
    
- Claridad en la delegación.
    
- Comunicación efectiva.
    
- Madurez y disposición del equipo.
definicion 2 de division organizacional:
**La acción de organizar comprende, entre otros aspectos, establecer departamentos.**  
El término departamento designa un área, una división o una unidad específica de una organización sobre la cual un gerente tiene autoridad para el desempeño de las actividades establecidas.

- Un departamento (como generalmente se utiliza el término) puede ser la división de producción, el departamento de ventas, la unidad de una región geográfica, la sección de investigación de mercados o la unidad de cuentas por cobrar.
    
- En algunas empresas la terminología departamental se utiliza con libertad; en otras, especialmente en las grandes, una terminología más estricta indica relaciones jerárquicas. Así, un vicepresidente puede encabezar una división; un director, un departamento; un gerente, una unidad; y un jefe, una sección.
![[Pasted image 20250521154348.png]]

#### **4. Describa la Reingeniería de la organización, detallando sus aspectos claves.**

**Definición:**  
Rediseño radical de procesos para mejorar desempeño en costos, calidad, y rapidez.

**Aspectos Claves:**

1. **Enfoque en procesos:** Revisar flujos de trabajo (ej: atención al cliente).
    
2. **Uso de tecnología:** Automatizar tareas repetitivas.
    
3. **Orientación al cliente:** Priorizar sus necesidades.
    
4. **Cambio cultural:** Fomentar innovación y flexibilidad.
    
5. **Resultados medibles:** Establecer KPIs (ej: tiempo de entrega).
Definicion 2:
**Hace algún tiempo, un concepto gerencial llamado “reingeniería” irrumpió en la bibliografía administrativa.**  
En ocasiones se le llama _volver a empezar_, porque Michael Hammer y James Champy, quienes popularizaron el concepto, sugirieron plantearse esta pregunta:

> “Si volviera a crear esta compañía hoy (partiendo de la nada), sabiendo lo que ahora sé y dada la tecnología actual, ¿cómo sería?”

- Hammer y Champy definen la reingeniería como:
    

> “...repetir el pensamiento fundamental y el rediseño radical de los procesos de negocios para obtener mejoras importantes en medidas decisivas de desempeño contemporáneas, como costos, calidad, servicio y rapidez.”

#### **6. Explique y grafique los diversos tipos de departamentalización.**

**Tipos:**

1. **Por Funciones:** Agrupa por especialidad (ej: Marketing, Finanzas).
    
    - _Ventaja:_ Eficiencia. _Desventaja:_ Poca flexibilidad.
        
2. **Por Territorio:** Divisiones geográficas (ej: Región Norte).
    
    - _Ventaja:_ Adaptación local. _Desventaja:_ Duplicación de recursos.
        
3. **Por Clientes:** Segmenta por tipo de cliente (ej: Banca Empresarial).
    
    - _Ventaja:_ Enfoque personalizado. _Desventaja:_ Coordinación compleja.
        
4. **Por Producto:** Divisiones por línea de productos (ej: Línea Electrónica).
    
    - _Ventaja:_ Especialización. _Desventaja:_ Competencia interna.
        

**Organización Matricial:**  
Combina funcional y por proyectos.

- _Ventaja:_ Flexibilidad. _Desventaja:_ Conflictos de autoridad.  
### Departamentalizacion por funciones:
Consiste en **agrupar actividades según las funciones básicas** que realiza una empresa: **producción**, **ventas/marketing** y **finanzas**. Es la forma más común de organización y refleja las funciones típicas de cualquier empresa.

![[Pasted image 20250521155152.png]]
 **Ventajas**
 • Es un reflejo lógico de las funciones.
 • Se conserva tanto la autoridad como la responsa
bilidad de las funciones principales.
 • Se sigue el principio de la especialización profe
sional.
 • Se simplifica la capacitación.
 • Se cuenta con medios para un riguroso control 
desde la cima.
 **Desventajas**
 • Se resta importancia a los objetivos generales de la empresa.
 • El punto de vista del personal clave se especializa en exceso y 
se limita.
 • Se reduce la coordinación entre funciones.
 • La responsabilidad de las utilidades se concentra exclusivamen
te en la cima.
 • Hay lenta adaptación a los cambios.
 • Se limita el desarrollo de gerentes generales.
### Departamentalizacion por territorios:
Es una forma de organización en la que **las actividades se agrupan según áreas geográficas** y se asignan a un **gerente responsable de cada territorio**.
![[Pasted image 20250521155415.png]]
 **Ventajas**
 • Coloca la responsabilidad en un nivel inferior.
 • Da importancia a mercados y problemas locales.
 • Mejora la coordinación de una región.
 • Aprovecha las economías de las operaciones locales.
 • Mejora la comunicación directa con los interesados en la localidad.
 • Proporciona una capacitación firme y perceptible para los gerentes 
generales.
 
 **Desventajas**
 • Requiere de más personas capacitadas en la 
gerencia general.
 • Tiende a hacer difícil la conservación de los 
principales servicios financieros y puede 
requerir de otros servicios, como personal o 
compras, en la región.
 • Dificulta el control a la alta gerencia.
### Departamentalizacion por clientes:
Es una forma de organización en la que las **actividades se agrupan según tipos específicos de clientes**, con el objetivo de **atender mejor sus necesidades**.
![[Pasted image 20250521160229.png]]
 **Ventajas**
 • Alienta el enfoque en las necesidades 
de los clientes.
 • Da a los clientes la sensación de que 
tienen un proveedor comprensivo (el 
banquero).
 • Desarrolla experiencias en las áreas de 
clientes.
 
 **Desventajas**
 • Puede ser difícil coordinar las operaciones entre las 
demandas de competitividad de los clientes.
 • Requiere de gerentes y personal especializados en los 
problemas de los clientes.
 • Es posible que los grupos de clientes no siempre estén 
bien definidos (p. ej., grandes empresas corporativas 
frente a otras empresas corporativas).

### Departamentalización   por producto:
 **Descripción:**

- Se utiliza en empresas con **múltiples líneas de productos** a gran escala.
    
- Suele surgir cuando una estructura funcional se vuelve **ineficiente con el crecimiento**.
    
- Permite **delegar autoridad** y **responsabilidad de utilidades** a ejecutivos de cada producto.
    
- Cada división maneja funciones como **manufactura, ventas, servicio e ingeniería** ligadas a un producto específico.

![[Pasted image 20250521161417.png]]
**Ventajas**

- Dirige la atención y los esfuerzos a la línea de productos.
    
- Facilita el uso del capital, las instalaciones, las habilidades y los conocimientos especializados.
    
- Permite el crecimiento y la diversidad de productos y servicios.
    
- Mejora la coordinación de las actividades funcionales.
    
- Asigna la responsabilidad de las utilidades al nivel divisional.
    
- Proporciona una capacitación firme y perceptible para los gerentes generales.
    

**Desventajas**

- Requiere de más personas con capacidades en la gerencia general.
    
- Tiende a dificultar el control financiero de los servicios generales.
    
- Presenta un problema creciente de supervisión desde la alta gerencia.

**Organización matricial:**  
Es una estructura organizacional que combina la departamentalización funcional y la departamentalización por proyectos o productos, donde los empleados reportan simultáneamente a gerentes funcionales y a gerentes de proyecto, facilitando la coordinación y el uso eficiente de recursos en tareas especializadas y proyectos específicos.
![[Pasted image 20250521161925.png]]
![[Pasted image 20250521162103.png]]
#### **7. Explique el concepto de Unidades Estratégicas de Negocio (UEN).**

**Definición:**  
Divisiones autónomas dentro de una empresa que gestionan un producto o mercado específico.

**Características:**

- Tienen su propia misión y competidores.
    
- Responsables de rentabilidad.
    
- Ejemplo: Una multinacional con UENs en alimentación y electrónica.

Descripcion Larga:
**Organización Matricial – Aplicación y Directrices**

La organización matricial se utiliza comúnmente en proyectos complejos que requieren la colaboración de expertos de diferentes áreas. Algunos ejemplos son la construcción, la industria aeroespacial, el marketing, la instalación de sistemas electrónicos y la consultoría administrativa.

Para que este tipo de organización funcione de manera efectiva, es importante seguir ciertas directrices:

1. **Definir claramente los objetivos del proyecto.**  
    Todos los miembros deben conocer qué se espera lograr.
    
2. **Establecer funciones, responsabilidades y niveles de autoridad.**  
    Tanto los gerentes como los equipos deben saber qué les corresponde hacer.
    
3. **Basar la participación en el conocimiento y la experiencia, no en la jerarquía.**  
    Lo importante es el aporte profesional, no el cargo.
    
4. **Mantener un equilibrio de poder entre los gerentes funcionales y los de proyecto.**  
    Ambos deben colaborar sin que uno tenga mayor dominio que el otro.
    
5. **Seleccionar un líder con experiencia para dirigir el proyecto.**  
    Un buen liderazgo es clave para coordinar equipos diversos.
    
6. **Fomentar el compromiso y el trabajo en equipo.**  
    La cooperación entre áreas mejora los resultados.
    
7. **Establecer controles adecuados sobre costos, plazos y calidad.**  
    Es fundamental monitorear el avance del proyecto.
    
8. **Recompensar de manera justa a todos los involucrados.**  
    Reconocer el esfuerzo motiva y refuerza el trabajo bien hecho.


#### **7. Explique el concepto de Unidades Estratégicas de Negocio (UEN).**

**Definición:**  
Divisiones autónomas dentro de una empresa que gestionan un producto o mercado específico.

**Características:**

- Tienen su propia misión y competidores.
    
- Responsables de rentabilidad.
    
- Ejemplo: Una multinacional con UENs en alimentación y electrónica.


definicion compleja:
El concepto de **Unidades Estratégicas de Negocio (UEN)** se refiere a una **estructura organizacional** dentro de una empresa grande, en la que **ciertos productos o líneas de productos** son gestionados como si fueran **empresas independientes**.

Cada UEN tiene su **propia misión, estrategias, recursos y objetivos**, distintos del resto de la organización. Su propósito es **dar enfoque y atención especializada** a productos importantes, evitando que se pierdan entre otros con mayor volumen o rentabilidad dentro de la empresa matriz.

### Características clave de una UEN:

- Tiene **competidores propios** definidos.
    
- Elabora sus **propios planes estratégicos y operativos**.
    
- Administra sus **recursos de forma autónoma**.
    
- Tiene un **tamaño adecuado** para operar de forma eficiente.
    
- Es dirigida por un **gerente responsable de toda la unidad**, desde el desarrollo del producto hasta su comercialización y rentabilidad.
    

### Objetivo principal:

Permitir que cada línea de productos reciba la misma atención que tendría si fuese gestionada por una empresa separada, manteniendo así el **enfoque, agilidad y espíritu emprendedor** dentro de grandes corporaciones.


#### **9. Explique los conceptos de autoridad y poder. En qué consiste delegación de poder de decisión.**

**Autoridad:**  
Derecho legítimo de un puesto para tomar decisiones (ej: gerente).

**Poder:**  
Capacidad de influir en otros, puede ser:

- **Conocimiento:** Experto técnico.
    
- **Referencia:** Carisma (ej: líder inspirador).
    
- **Recompensa/Coerción:** Premios o sanciones.
    

**Delegación de Poder de Decisión (Empowerment):**  
Otorgar autonomía a empleados para decidir sin aprobación jerárquica, basado en confianza y responsabilidad.
 Definicion Compleja:
 **Autoridad**
La **autoridad** es el **derecho legítimo** que tiene una persona, por ocupar un determinado cargo en una organización, para tomar decisiones que afectan a otros.  
Es una **forma de poder**, pero dentro del marco formal de una estructura organizacional.  
Por ejemplo: un gerente tiene autoridad para asignar tareas o tomar decisiones que afecten al equipo.

### **Poder**

El **poder** es la **capacidad de influir** en las acciones, pensamientos o decisiones de otras personas o grupos, independientemente de si se tiene un cargo formal o no.

Existen distintos **tipos de poder**:

1. **Poder legítimo:**  
    Deriva del cargo que se ocupa (por ejemplo, un jefe o gerente).
    
2. **Poder del conocimiento:**  
    Proviene del saber o la experiencia especializada.  
    Ej.: médicos, abogados, profesores.
    
3. **Poder de referencia:**  
    Es la influencia basada en el respeto, admiración o carisma.  
    Ej.: líderes como Martin Luther King o celebridades.
    
4. **Poder de recompensa:**  
    Es la capacidad de ofrecer beneficios o incentivos a otros (aumento, promoción, premios).
    
5. **Poder coercitivo:**  
    Es la capacidad de castigar o imponer sanciones (despido, retiro de beneficios).  
    Suele estar relacionado con el poder legítimo.
    
### **Delegación del poder de decisión (Empowerment)**

Consiste en **darle a los empleados o equipos la autoridad para tomar decisiones sin necesidad de aprobación de sus superiores**.

#### Objetivos:

- Aprovechar el conocimiento de quienes están más cerca del problema o tarea.
    
- Motivar al personal al hacerlo partícipe de las decisiones.
    
- Mejorar la eficiencia y la capacidad de respuesta.
    

#### Condiciones para que funcione:

- Que los empleados tengan las **capacidades necesarias**.
    
- Que acepten la **responsabilidad** por sus decisiones.
    


### **Relación entre poder y responsabilidad**

Según el principio de **paridad de autoridad y responsabilidad (P = R)**:

- Si una persona tiene **más poder que responsabilidad (P > R)** → puede volverse autoritaria.
    
- Si tiene **más responsabilidad que poder (R > P)** → puede sentirse frustrada por no tener los medios para cumplir con lo que se le exige.


#### **10. Defina los conceptos de autoridad de línea, staff, y autoridad funcional.**

**Autoridad de Línea:**  
Derecho de supervisar directamente subordinados (ej: gerente de ventas).

**Staff:**  
Roles de asesoría sin mando directo (ej: consultor legal).

**Autoridad Funcional:**  
Derecho limitado sobre procesos específicos (ej: QA que dicta normas a producción).

Definicion completa:
### **10. Defina los conceptos de autoridad de línea, staff, y autoridad funcional**

#### **1. Autoridad de Línea**

- **Definición:** Derecho jerárquico que tiene un superior (ej: gerente) para tomar decisiones y dar órdenes _directas_ a sus subordinados dentro de una cadena de mando formal.
    
- **Características:**
    
    - Es la base de la estructura piramidal (ej: Presidente → Gerente → Supervisor).
        
    - Sigue el principio de **escalonamiento**: claridad en la línea de autoridad desde el nivel más alto al más bajo.
        
    - **Ejemplo:** Un gerente de producción que supervisa a los operarios.
        

#### **2. Personal de Staff**

- **Definición:** Roles que brindan _asesoría_, apoyo especializado o servicios a los gerentes de línea, pero **sin autoridad directa** sobre ellos.
    
- **Características:**
    
    - Función consultiva (ej: asesor legal, departamento de RR.HH.).
        
    - No emiten órdenes, pero influyen en decisiones mediante recomendaciones.
        
    - **Ejemplo:** Un consultor financiero que aconseja al gerente de ventas sobre presupuestos.
        

#### **3. Autoridad Funcional**

- **Definición:** Derecho _limitado y específico_ delegado a un individuo o departamento para controlar procesos, políticas o estándares en áreas transversales.
    
- **Características:**
    
    - Combina aspectos de línea y staff: puede dar instrucciones sobre su ámbito específico (ej: calidad, seguridad) incluso a otros departamentos.
        
    - **Ejemplo:** El jefe de control de calidad que exige ajustes en producción para cumplir normas.
        

---

### **Diferencias Clave**

| **Tipo**      | **Poder de Decisión** | **Función Principal** | **Ejemplo**                   |
| ------------- | --------------------- | --------------------- | ----------------------------- |
| **Línea**     | Directo y jerárquico  | Mandar y ejecutar     | Gerente operativo.            |
| **Staff**     | Ninguno               | Asesorar/recomendar   | Asesor legal.                 |
| **Funcional** | Parcial (específico)  | Regular procesos      | Jefe de seguridad industrial. |

**Importante:** La autoridad funcional debe definirse claramente para evitar conflictos con la línea jerárquica tradicional.


# Trabajo Practico N°4

#### **1. Definición de integración de personal**

definicon completa :
#### **1. Defina integración de personal**

La integración de personal es un proceso sistemático que consiste en identificar, reclutar, seleccionar, capacitar y retener a los colaboradores adecuados para cubrir las necesidades de una organización. Su objetivo es alinear las habilidades, competencias y valores de los empleados con los objetivos organizacionales, garantizando un ambiente laboral productivo y cohesionado. Incluye etapas como la planificación de recursos humanos, la selección, la inducción, el desarrollo y la evaluación del desempeño

La **integración de personal (staffing)** es una función gerencial clave que consiste en cubrir y mantener los cargos dentro de la estructura organizacional. Esto implica:

- **Identificar necesidades laborales** según los objetivos de la empresa.
    
- **Reclutar, seleccionar, colocar y promover** talentos alineados con los requisitos del puesto.
    
- **Evaluar, capacitar y desarrollar** a los empleados para garantizar eficiencia y eficacia en sus roles.
    
- **Vincularse con la organización** mediante estructuras intencionales de funciones y jerarquías.
    

**Enfoque sistémico:**

- Se basa en comparar la demanda de gerentes/profesionales (determinada por la estructura organizacional) con el talento disponible (inventario profesional), utilizando fuentes internas y externas.


### **4. Describa los factores situacionales que afectan la integración de personal (ambiente externo y ambiente interno)**

**Ambiente externo**:

- Nivel educativo de la población
    
- Actitudes sociales hacia el trabajo
    
- Legislación y reglamentos laborales
    
- Condiciones económicas generales
    
- Oferta y demanda de administradores en el mercado
    

**Ambiente interno**:

- Metas organizacionales
    
- Tipo de tareas y tecnología utilizada
    
- Estructura de la organización
    
- Tipo de empleados contratados
    
- Oferta y demanda de gerentes dentro de la empresa
    
- Sistema de compensaciones
    
- Políticas internas
    

Cada uno de estos factores influye en la forma en que se integran y retienen los recursos humanos en una organización


### **6. Describa los requisitos del cargo y diseño de puesto**

Los **requisitos del cargo** representan las **condiciones mínimas necesarias** para que una persona pueda desempeñar un determinado puesto (educación, experiencia, habilidades, etc.).

El **diseño de puesto**, por su parte, es el **proceso de estructuración de las tareas**, responsabilidades y relaciones laborales para lograr la eficiencia en el trabajo. Ambos elementos son fundamentales para lograr una buena selección y desempeño del personal

**Requisitos:**

- **Formación:** Títulos o certificaciones exigidas.
    
- **Experiencia:** Años en roles similares.
    
- **Habilidades:**
    
    - _Técnicas:_ Uso de software específico (ej.: CRM).
        
    - _Blandas:_ Liderazgo, comunicación (según el enfoque sistémico de selección).
        

**Diseño del puesto:**

- **Tareas y responsabilidades:** Descripción detallada de actividades diarias.
    
- **Jerarquía:** Reportes y supervisión.
    
- **Condiciones laborales:** Horarios, modalidad (híbrido/presencial).
    

**Base teórica:**  
El enfoque sistémico compara estos requisitos con las **características individuales** (inteligencia, conocimientos, actitudes) para asegurar un match efectivo.

### **7. Describa las habilidades y características personales necesarias en los administradores**

Habilidades necesarias:

- **Capacidad analítica** y de **resolución de problemas**
    
- Habilidades de **comunicación**
    
- **Empatía** y manejo de relaciones interpersonales
    

Características personales deseables:

- Deseo de administrar
    
- **Integridad y honestidad**
    
- Orientación a resultados
    

Estas competencias permiten a los administradores liderar con efectividad y tomar decisiones acertadas en contextos complejos

### **9. Describa el proceso de selección, técnicas e instrumentos**

El **proceso de selección** busca identificar al candidato más adecuado para un puesto específico. Involucra:

- **Criterios de selección**: Educación, conocimientos, experiencia, habilidades.
    
- **Entrevistas**: Estructuradas, semiestructuradas y no estructuradas.
    
- **Pruebas**:
    
    - Inteligencia
        
    - Aptitud
        
    - Personalidad
        
    - Vocacionales
        
- **Centros de evaluación**: Simulan situaciones gerenciales para predecir el desempeño futuro.
    

Se requiere que la información sea **válida** (mide lo que debe medir) y **confiable** (consistente en el tiempo)

definicion 2:
### El proceso de selección, técnicas e instrumentos

- Para una buena selección, la información sobre el solicitante debe ser **válida y confiable**.  
    Cuando se pregunta si los datos son válidos, se refiere a si **miden lo que deben medir**.  
    En la selección, **validez** es el grado al cual los datos predicen el éxito del candidato como gerente.
    
- La información también debe tener un alto grado de **confiabilidad**, un término que se refiere a la **precisión y congruencia de la medición**;  
    por ejemplo, si se repite una prueba confiable en las mismas condiciones, en esencia arrojaría los mismos resultados.
    
### Técnicas e instrumentos:

- **Criterios de selección:** educación, conocimientos, habilidades y experiencia.
    
- **Entrevistas:** estructuradas, semiestructuradas y no estructuradas.
    
- **Pruebas:** de inteligencia, de pericia y aptitud, vocacionales, y de personalidad.
    
- **Centros de evaluación:** tienen el propósito de medir cómo actuará un gerente potencial en situaciones gerenciales típicas.

### **12. Describa cómo evaluar a los administradores con base en objetivos cuantificables**

La evaluación de administradores basada en **objetivos cuantificables** se centra en medir su desempeño contra **metas claramente definidas**. Esto implica:

- Establecer **indicadores de desempeño (KPIs)**
    
- Relacionar los resultados obtenidos con los **objetivos organizacionales**
    
- Cuantificar logros (ventas, reducción de costos, productividad, etc.)
    

Este enfoque permite tomar decisiones objetivas sobre promociones, recompensas o reestructuraciones
![[Pasted image 20250522151059.png]]
definicion 2:
### ** Describa cómo evaluar a los administradores con base en objetivos cuantificables**

Evaluar a los administradores con base en **objetivos cuantificables** implica establecer criterios claros y medibles que permitan determinar su desempeño. Este enfoque se basa en comparar los **resultados reales obtenidos** con los **objetivos previamente definidos**.

#### Pasos clave en la evaluación:

1. **Definición de objetivos**: Deben ser específicos, medibles, alcanzables, relevantes y temporales (criterio SMART).
    
2. **Medición de desempeño**: Se utilizan indicadores cuantitativos como:
    
    - Incremento en la productividad
        
    - Reducción de costos
        
    - Cumplimiento de metas de ventas
        
    - Mejora en la eficiencia de procesos
        
3. **Aplicación de técnicas e instrumentos de selección** (para entender el potencial del administrador en sus funciones):
    
    - **Pruebas**: De inteligencia, aptitud, personalidad y vocacionales.
        
    - **Entrevistas**: Estructuradas y semiestructuradas para conocer competencias clave.
        
    - **Centros de evaluación**: Simulan situaciones reales para evaluar cómo actúan los gerentes ante desafíos típicos del cargo.
        
4. **Confiabilidad y validez de los datos**:
    
    - **Validez**: Los datos deben predecir con precisión el éxito del administrador.
        
    - **Confiabilidad**: Los resultados deben ser consistentes al repetirse las evaluaciones en condiciones similares.
        

Este método permite tomar decisiones objetivas para la promoción, retención, capacitación o reemplazo de administradores.
### **15. Describa y grafique cómo formular la estrategia de carrera profesional**

La estrategia de carrera profesional se formula mediante un proceso estructurado que permite al individuo **definir metas personales y profesionales**, evaluar sus capacidades, y establecer un plan para alcanzar esas metas. Este proceso incluye:

1. **Perfil personal**: Conocimiento de uno mismo (intereses, valores, capacidades).
    
2. **Metas personales y profesionales a largo plazo**: Qué se desea lograr en la vida y en la profesión.
    
3. **Condiciones (amenazas y oportunidades)**: Evaluación del entorno externo.
    
4. **Fortalezas y debilidades personales**: Análisis interno del individuo.
    
5. **Opciones profesionales**: Identificación de caminos de desarrollo posibles.
    
6. **Prueba de congruencia y elecciones estratégicas**: Selección de la mejor opción basada en la coherencia entre el perfil, metas y entorno.
    
7. **Objetivos y planes de acción a corto plazo**: Acciones concretas para avanzar en la carrera.
    
8. **Planes de contingencia**: Alternativas ante imprevistos.
    
9. **Instrumentación del plan**: Ejecución del plan profesional.
    
10. **Supervisión del progreso y retroalimentación**: Revisión constante para ajustar el rumbo.
![[Pasted image 20250522150713.png]]
## Trabajo Practico N°5

 #### **1. Defina Dirección y describa los factores humanos en la administración.**

**Dirección**: Es la función gerencial que consiste en influir en las personas para que contribuyan al logro de los objetivos organizacionales y grupales.
Elementos de la direccion: Incluye liderazgo, motivación y comunicación.

**Factores humanos en la administración**:

- **Multiplicidad de roles**: Las personas son miembros de sistemas sociales, consumidores y parte de familias u otras organizaciones.
    
- **Individualidad**: No existen personas "promedio"; cada una tiene necesidades, ambiciones y habilidades únicas.
    
- **Dignidad personal**: Tratar a las personas con respeto, independientemente de su cargo.
    
- **Persona como un todo**: Las personas están influenciadas por factores externos (familia, sociedad) que afectan su desempeño laboral.
#### **2. Defina motivación. Describa el modelo conducta de la teoría X y la teoría Y de McGregor.**

**Motivación**: Es el conjunto de impulsos, deseos y necesidades que inducen a las personas a actuar de cierta manera para alcanzar objetivos.

**Teoría X**:

- Supone que las personas evitan el trabajo y la responsabilidad.
    
- Requieren control externo, castigos o recompensas para esforzarse.
    
- Prefieren seguridad y dirección.
    

**Teoría Y**:

- Asume que el trabajo es natural como el juego o el descanso.
    
- Las personas se autodirigen y autocontrolan si están comprometidas con los objetivos.
    
- Buscan responsabilidad y creatividad en condiciones adecuadas.


definicion amplia:
### **. Defina motivación. Describa el modelo conducta de la teoría X y la teoría de Y de McGregor.**

**Motivación:**  
Es un conjunto de impulsos, deseos, necesidades o fuerzas internas (conscientes o inconscientes) que mueven a una persona a actuar de cierta manera para satisfacer sus necesidades. En el ámbito organizacional, los gerentes motivan a sus empleados al generar condiciones que despierten esos impulsos y los orienten hacia el cumplimiento de los objetivos de la organización.


### **Teoría X y Teoría Y de McGregor**

Douglas McGregor propuso dos enfoques sobre la naturaleza humana que reflejan cómo los gerentes perciben a sus colaboradores. Estas teorías no son recetas gerenciales, sino supuestos que deben ser probados frente a la realidad y adaptados según la situación.

#### **Teoría X** (visión pesimista y controladora):

- Las personas sienten un rechazo natural hacia el trabajo y lo evitarán si pueden.
    
- Es necesario obligar, controlar o amenazar con castigos para que trabajen.
    
- Prefieren ser dirigidas, evitar responsabilidades, tienen poca ambición y buscan seguridad.
    

 Este modelo justifica un estilo de dirección autoritario, con supervisión estricta y control externo.


####  **Teoría Y** (visión optimista y participativa):

- El trabajo es tan natural como jugar o descansar.
    
- Las personas pueden autodirigirse y autocontrolarse si están comprometidas con los objetivos.
    
- El compromiso depende del valor de las recompensas asociadas.
    
- Bajo condiciones apropiadas, buscan asumir responsabilidades.
    
- En la vida moderna, el ser humano solo utiliza una parte de su potencial intelectual.
    

 Este enfoque promueve la participación, el desarrollo del talento y la integración entre metas personales y organizacionales.
### Teoría X y Teoría Y de McGregor - Explicación Ampliada**

#### **Definición y Contexto**

Douglas McGregor, en su obra _"El lado humano de las empresas"_ (1960), propuso dos conjuntos de supuestos sobre la naturaleza humana que influyen en el estilo de gestión:

- **Teoría X**: Visión tradicional y pesimista.
    
- **Teoría Y**: Enfoque moderno y optimista.
    

McGregor argumentó que la efectividad de un líder depende de su percepción sobre la motivación y capacidad de sus colaboradores.

#### **Supuestos de la Teoría X**

1. **Naturaleza del trabajo**:
    
    - Los seres humanos sienten aversión intrínseca al trabajo y lo evitan si es posible.
        
2. **Control necesario**:
    
    - Requieren supervisión estricta, coerción y castigos para alcanzar objetivos organizacionales.
        
3. **Preferencias individuales**:
    
    - Buscan seguridad, evitan responsabilidades y prefieren ser dirigidos.
        

**Implicaciones gerenciales**:

- Estilo **autocrático**.
    
- Estructuras rígidas con jerarquías claras.
    
- Uso de recompensas extrínsecas (salario) y castigos.
    

**Ejemplo**: Fábricas con tareas repetitivas donde la creatividad es limitada.

#### **Supuestos de la Teoría Y**

1. **Naturaleza del trabajo**:
    
    - El esfuerzo físico/mental en el trabajo es tan natural como el descanso o el juego.
        
2. **Autonomía**:
    
    - Las personas se autodirigen y autocontrolan si están comprometidas con las metas.
        
3. **Responsabilidad y potencial**:
    
    - Bajo condiciones adecuadas, buscan responsabilidades y desarrollan creatividad.
        

**Implicaciones gerenciales**:

- Estilo **participativo/delegativo**.
    
- Ambiente que fomenta la innovación y el crecimiento.
    
- Motivación intrínseca (reconocimiento, desarrollo profesional).
    

**Ejemplo**: Empresas tecnológicas como Google, donde se promueve la autonomía.
#### **Comparación Crítica**

| **Aspecto**               | **Teoría X**           | **Teoría Y**                  |
| ------------------------- | ---------------------- | ----------------------------- |
| **Visión del ser humano** | Pasivo, evita trabajo. | Activo, busca desafíos.       |
| **Control**               | Externo (supervisión). | Interno (autogestión).        |
| **Estilo de liderazgo**   | Autocrático.           | Democrático/transformacional. |
| **Contexto ideal**        | Tareas rutinarias.     | Entornos dinámicos/creativos. |


#### **Aclaraciones Clave**

- **No son dicotómicas**: Un gerente puede aplicar elementos de ambas según la situación (_enfoque situacional_).
    
- **No son juicios de valor**: McGregor no las clasifica como "buenas" o "malas", sino como marcos para entender comportamientos.
    
- **Flexibilidad**: La Teoría Y no rechaza la autoridad, sino que integra necesidades individuales y organizacionales.
#### **Conclusión**

Las teorías de McGregor destacan que el **estilo de gestión depende de la percepción del líder sobre su equipo**. Mientras la Teoría X enfatiza el control, la Teoría Y promueve la confianza y el desarrollo. Su relevancia persiste en la gestión moderna, especialmente en debates sobre flexibilidad laboral y bienestar organizacional.

### **3. Describa y grafique la jerarquía de las necesidades de Maslow.**

**Jerarquía de Maslow (de abajo hacia arriba):**

1. **Fisiológicas:** comida, agua, abrigo.
    
2. **Seguridad:** protección física y económica.
    
3. **Afiliación:** pertenencia, amor, relaciones.
    
4. **Estima:** respeto, estatus, reconocimiento.
    
5. **Autorrealización:** desarrollo del potencial personal.
![[Pasted image 20250522153927.png]]
definicion 2:
- **Necesidades fisiológicas:**  
    Son las necesidades básicas para sostener la vida humana, como el **alimento, agua, calor, abrigo y sueño**.
    
- **Necesidades de seguridad:**  
    Las personas desean estar libres de **peligros físicos** y del temor de **perder el trabajo, las propiedades, los alimentos o el abrigo**.
    
- **Necesidades de afiliación o aceptación:**  
    Dado que las personas son seres sociales, necesitan un **sentido de pertenencia**, es decir, **ser aceptadas por otros**.
    
- **Necesidades de estima:**  
    Una vez que las personas satisfacen su necesidad de pertenencia, tienden a **querer ser tenidas en alta estima**, tanto por sí mismas como por los demás.  
    Este tipo de necesidad genera satisfacciones como el **poder, prestigio, estatus y autoconfianza**.
    
- **Necesidad de autorrealización:**  
    Es la **máxima necesidad** en la jerarquía de Maslow. Representa el deseo de **convertirse en lo que uno es capaz de ser**, **maximizar el propio potencial** y **lograr metas significativas**.

### **4. Grafique y explique la Teoría de la motivación-higiene de Herzberg**

**La Teoría de los Dos Factores** fue propuesta por **Frederick Herzberg** como una revisión crítica de la jerarquía de necesidades de Maslow. Su objetivo era identificar qué factores realmente generan satisfacción en el trabajo.
### 🔹 Herzberg distingue dos grupos de factores:

####  **Factores Higiénicos (Insatisfactores)**

- Política y estilo de dirección de la empresa
    
- Supervisión
    
- Condiciones físicas de trabajo
    
- Relaciones interpersonales
    
- Salario
    
- Estatus
    
- Seguridad laboral
    
- Vida personal
    

Estos factores **no generan motivación**, pero su **ausencia causa insatisfacción**.  
Incluso si están presentes en abundancia, **no producen satisfacción real**, sólo previenen el descontento.

####  **Factores Motivadores (Satisfactores)**

- Logro
    
- Reconocimiento
    
- Trabajo desafiante
    
- Crecimiento profesional
    
- Responsabilidad
    
- Avance en el puesto
    

 **Estos sí generan motivación y satisfacción**.  
Cuando están presentes, hacen que la persona se sienta realizada y comprometida.

![[Pasted image 20250522154437.png]]
### **Conclusión según Herzberg:**

- Los **factores higiénicos** son necesarios para evitar la insatisfacción, pero **no motivan**.
    
- Los **motivadores** son los únicos que realmente **producen satisfacción y motivación intrínseca** en el trabajo.


Definicion Extensa:
### Cuestionamientos a la Jerarquía de Maslow – Teoría de los dos factores de Herzberg

- **Frederick Herzberg** y sus colaboradores **modificaron de manera considerable el enfoque de las necesidades de Maslow**.  
    Su investigación propuso una **teoría de dos factores de la motivación**.
    
- En un primer grupo de necesidades están:
    
    - La política y estilo de dirección de la compañía
        
    - La supervisión
        
    - Las condiciones de trabajo
        
    - Las relaciones interpersonales
        
    - El salario
        
    - El estatus
        
    - La seguridad en el empleo
        
    - La vida personal
        
    
    Herzberg encontró que **estos factores solo generan insatisfacción cuando están ausentes o son deficientes**, pero **no motivan**.  
    Incluso si se ofrecen en alta cantidad y calidad, **no generan satisfacción**, solo **evitan la insatisfacción**. A estos los llamó **"factores higiénicos"** o **"insatisfactores"**.
    
- En el segundo grupo, Herzberg lista ciertos **satisfactores**, por tanto **motivadores**, todos relacionados con el **contenido del trabajo**.  
    Incluyen:
    
    - El logro
        
    - El reconocimiento
        
    - El trabajo desafiante
        
    - El avance
        
    - El crecimiento en el trabajo
        
    
    La existencia de estos factores **genera satisfacción** o **no satisfacción**, pero **no insatisfacción**.
    

### Conclusión de Herzberg:

- El **primer grupo** de factores (los insatisfactores o higiénicos) **no motiva**, pero **su ausencia genera insatisfacción**.
    
- El **segundo grupo** (los factores relacionados al contenido del trabajo) **son los verdaderos motivadores**, porque **despiertan un sentido de satisfacción real**.

**Teoría de Herzberg (dos factores):**

- **Factores higiénicos:** (no motivan, pero su ausencia causa insatisfacción) salario, condiciones laborales, supervisión, políticas.
    
- **Factores motivadores:** (generan satisfacción) logro, reconocimiento, responsabilidad, crecimiento personal.

### **8. Describa la teoría de las necesidades de la motivación de McClelland.**

McClelland identifica tres necesidades principales:

- **Necesidad de logro:** deseo de éxito, metas desafiantes, evitar el fracaso.
    
- **Necesidad de afiliación:** relaciones sociales positivas, evitar el rechazo.
    
- **Necesidad de poder:** influir, controlar y liderar a otros.
Definicion extensa:
### Teoría de las necesidades de la motivación de McClelland

Según McClelland, existen **tres necesidades motivadoras básicas**:

1. **Necesidad de poder:**
    
    - Las personas con alta necesidad de poder se preocupan mucho por **ejercer influencia y control**.
        
    - Suelen buscar cargos de liderazgo y a menudo son **buenos conversadores**, aunque también pueden ser discutidores.
        
    - Les gusta **imponerse**, suelen ser **expresivos, obstinados y exigentes**, y disfrutan **enseñar y hablar en público**.
        
2. **Necesidad de afiliación:**
    
    - A las personas con alta necesidad de afiliación les gusta sentirse **amadas y aceptadas**, y tienden a evitar el dolor del **rechazo social**.
        
    - Se preocupan por **mantener relaciones sociales agradables**, disfrutan de la **intimidad y comprensión**, y están dispuestas a **consolar y ayudar** a otros con problemas.
        
    - Disfrutan la **interacción amistosa** con los demás.
        
3. **Necesidad de logro:**
    
    - Estas personas tienen un **intenso deseo de éxito** y un **temor igual de intenso al fracaso**.
        
    - Les gusta **ser desafiadas** y se fijan **metas moderadamente difíciles**, pero alcanzables.
        
    - Adoptan un **enfoque realista del riesgo**, no son jugadores, prefieren **analizar, evaluar problemas y asumir responsabilidad personal** para asegurarse de que el trabajo se realice correctamente.

### **10. Describa el enriquecimiento del puesto.**

Es una estrategia para hacer los trabajos más motivadores. Incluye:

1. Mayor autonomía.
    
2. Participación e interacción.
    
3. Sentido de responsabilidad.
    
4. Visión del impacto de su trabajo.
    
5. Retroalimentación directa.
    
6. Influencia sobre el ambiente laboral.
    

Relacionado con la teoría de Herzberg, busca aumentar la motivación intrínseca.

Forma mas completa:
### Enriquecimiento del puesto

La investigación y el análisis de la motivación señalan la importancia de hacer los **puestos desafiantes y significativos**, tanto en niveles **gerenciales como no gerenciales**.

El enriquecimiento del puesto se relaciona con la **teoría de la motivación de Herzberg**, en la que factores como el **desafío, el logro, el reconocimiento y la responsabilidad** son los verdaderos motivadores.

Para enriquecer un puesto, se pueden aplicar las siguientes acciones:

1. **Dar a los trabajadores mayor libertad** para decidir sobre aspectos como:
    
    - Métodos de trabajo
        
    - Secuencias y ritmos
        
    - Aceptación o rechazo de materiales
        
2. **Fomentar la participación de los subordinados** y la **interacción entre los trabajadores**.
    
3. **Dar a los trabajadores la sensación de responsabilidad personal** en sus actividades.
    
4. Asegurarse de que los trabajadores **puedan ver cómo sus actividades contribuyen** a un producto terminado y al bienestar de la empresa.
    
5. **Proporcionar retroalimentación sobre su desempeño**, preferiblemente **antes de que los supervisores la obtengan**.
    
6. **Involucrar a los trabajadores en el análisis y cambio de aspectos físicos del ambiente de trabajo**, como:
    
    - Distribución del espacio
        
    - Temperatura
        
    - Iluminación
        
    - Limpieza de la oficina o planta


#### **11. Defina el concepto de Liderazgo; sus componentes; los enfoques en las características del liderazgo.**

**Liderazgo**: Proceso de influir en personas para lograr metas con disposición y entusiasmo.

**Componentes**:

1. Uso responsable del poder.
    
2. Comprensión de motivaciones humanas.
    
3. Capacidad de inspirar.
    
4. Creación de un clima motivador.
    

**Enfoques**:

- **Rasgos**: Cualidades innatas (ej. carisma).
    
- **Conductual**: Estilos (autocrático, democrático).
    
- **Situacional**: Adaptación al contexto.



### **Enfoques Basados en Características del Liderazgo**

Estos enfoques se centran **exclusivamente en los atributos personales** (físicos, psicológicos o intelectuales) que diferencian a los líderes de los no líderes. **No consideran comportamientos ni contextos**, solo rasgos inherentes.

#### **1. Teoría de los Rasgos (Trait Theory)**

**Premisa:**  
"Los líderes nacen, no se hacen". Busca identificar **rasgos universales** que predicen el liderazgo efectivo.

**Características clave:**

- **Carisma:** Capacidad de inspirar y generar adhesión (ej.: Steve Jobs).
    
- **Confianza en sí mismo:** Seguridad para tomar decisiones.
    
- **Integridad:** Coherencia ética y honestidad.
    
- **Inteligencia:** Capacidad analítica y de resolución de problemas.
    
- **Determinación:** Persistencia ante obstáculos (ej.: Mahatma Gandhi).
    

**Críticas:**

- No todos los líderes comparten los mismos rasgos.
    
- Ignora que el contexto puede requerir características distintas (un líder carismático puede fracasar en una crisis técnica).

#### **Enfoque Conductual (Estilos de Liderazgo)**

**Premisa:**  
"El liderazgo se define por **acciones**, no solo por rasgos". Clasifica estilos según cómo actúa el líder.

**Estilos principales:**

- **Autocrático:** Decide solo (ej.: capitán en emergencias).
    
- **Democrático:** Fomenta participación (equipos creativos).
    
- **Laissez-faire:** Delega autonomía (equipos expertos).
    

**Ejemplo:**  
Un gerente **democrático** consulta a su equipo antes de lanzar un producto.

**Limitación:**  
No considera que el estilo ideal puede variar según la situación.

#### ** Enfoque Situacional (Contingencia)**

**Premisa:**  
"El líder efectivo **se adapta** al contexto y a su equipo".

**Variables clave:**

- Madurez del equipo.
    
- Urgencia de la tarea.
    
- Cultura organizacional.
    

**Ejemplo:**  
Un líder puede ser **autocrático** en una crisis (como el vuelo 1549 del Hudson) y **participativo** en un proyecto innovador.

**Modelo destacado:**

- **Hersey-Blanchard:** El líder ajusta su estilo según la **competencia** y **motivación** del equipo.
    

**Limitación:**  
Requiere flexibilidad y diagnóstico constante.

### **Conclusión**

"Los tres enfoques son complementarios:

1. Los **rasgos** explican el potencial.
    
2. Los **estilos** guían las acciones.
    
3. La **situación** determina qué aplicar.
    

Un líder excelente combina sus **cualidades innatas**, **estilos flexibles** y **adaptación al contexto**."

- #### **Diferencias clave con otros enfoques**

Para evitar confusiones, contrastemos con los enfoques que **no** son basados en características:

| **Enfoque**            | **Base**               | **Ejemplo**                                             |
| ---------------------- | ---------------------- | ------------------------------------------------------- |
| **Teoría de Rasgos**   | Atributos personales   | Líder carismático como Jobs.                            |
| **Teoría Conductual**  | Acciones y estilos     | Líder autocrático vs. democrático.                      |
| **Teoría Situacional** | Adaptación al contexto | Líder que cambia su estilo según la madurez del equipo. |
Complemento:
### Liderazgo

- **Liderazgo** se define como **"influencia"**, es decir, el arte o proceso de influir en las personas para que **participen con disposición y entusiasmo** en el logro de los objetivos del grupo.
    
- En teoría, no solo se debe alentar a las personas a que trabajen con disposición, sino también a que lo hagan con **fervor y confianza**.
    
    - **Fervor:** energía, entusiasmo e intensidad en la ejecución del trabajo.
        
    - **Confianza:** refleja la experiencia y la capacidad técnica.
        
- Los líderes actúan para ayudar a que un grupo alcance los objetivos **aplicando al máximo sus capacidades**.  
    No se colocan detrás del grupo para empujar, sino **delante, para facilitar el progreso e inspirar el logro de las metas organizacionales**.
    
- Un buen ejemplo es el **líder de una orquesta**, cuya función es producir un sonido coordinado y al ritmo adecuado mediante el esfuerzo integrado de los músicos.  
    La ejecución dependerá de la **calidad del liderazgo** del director.
    
### Componentes del liderazgo

Un líder efectivo debe **vivir y cimentar valores**, como el interés por la calidad, la honestidad, la disposición a asumir riesgos calculados, y la preocupación por los empleados y clientes.

Las habilidades del liderazgo combinan al menos **cuatro componentes importantes**:

1. **Capacidad de usar el poder con eficacia y responsabilidad.**
    
2. **Capacidad de comprender que las personas tienen diferentes motivaciones** en distintos momentos y situaciones.
    
3. **Capacidad de inspirar.**
    
4. **Capacidad de crear un clima favorable**, despertar motivaciones y hacer que las personas respondan a ellas.

### 12.Describa los estilos de liderazgo basados en el uso de la autoridad.

![[Pasted image 20250523014601.png]]
**Líder autocrático**  
Ordena y espera cumplimiento, es dogmático y positivo, y dirige mediante su capacidad para negar u otorgar recompensas y castigos.

**Líder democrático o participativo**  
Consulta con sus subordinados y fomenta su participación.

**Líder liberal**  
Utiliza muy poco su poder (si es que lo hace) y otorga a sus subordinados un alto grado de independencia.

**Autócratas benevolentes**  
Escuchan las opiniones de sus seguidores antes de tomar una decisión pero son ellos quienes deciden.


### **15. Describa el enfoque situacional o de contingencia del liderazgo**

El **enfoque situacional o de contingencia del liderazgo** sostiene que **no existe un único estilo de liderazgo eficaz en todas las situaciones**. La efectividad del liderazgo **depende de las condiciones del entorno, las características de los seguidores y las tareas a realizar**.

Uno de los principales exponentes de este enfoque es **Fred Fiedler**, quien propuso que el estilo de liderazgo (orientado a la tarea o a las relaciones) debe ajustarse según tres factores:

1. **Relación líder-miembro:** grado de confianza y respeto que los seguidores tienen hacia el líder.
    
2. **Estructura de la tarea:** claridad con la que están definidas las tareas a realizar.
    
3. **Poder del líder:** nivel de autoridad formal que tiene el líder.
    

Fiedler concluyó que:

- En **situaciones muy favorables o muy desfavorables**, es más eficaz un **líder orientado a la tarea**.
    
- En **situaciones moderadas**, es mejor un **líder orientado a las relaciones**.


### 16.**Teoría de la Ruta-Meta (Path-Goal Theory)**

La teoría de la ruta-meta, propuesta por **Robert House**, sostiene que la función principal del líder es:

> **Aclarar y establecer metas con los subordinados, ayudarlos a encontrar la mejor ruta para alcanzarlas y eliminar los obstáculos que dificulten ese camino.**

Se basa en diversas teorías de la **motivación** y del **liderazgo**, y propone que el liderazgo eficaz depende de factores **situacionales** como:

1. **Características de los subordinados:**
    
    - Necesidades individuales
        
    - Confianza en sí mismos
        
    - Habilidades
        
2. **Ambiente de trabajo:**
    
    - Tipo de tarea
        
    - Sistema de recompensas
        
    - Relaciones con los compañeros
        
### **Estilos de liderazgo según la Teoría de la Ruta-Meta**

La teoría clasifica el comportamiento del líder en **cuatro estilos** principales:

1. **Liderazgo de apoyo:**
    
    - Se enfoca en las **necesidades emocionales y personales** de los subordinados.
        
    - Crea un **clima organizacional agradable**.
        
    - Es más eficaz cuando los subordinados están **frustrados o insatisfechos**.
        
2. **Liderazgo participativo:**
    
    - Permite a los subordinados **influir en las decisiones** del líder.
        
    - Esto puede **aumentar la motivación** y el compromiso.
        
3. **Liderazgo instrumental (directivo):**
    
    - Proporciona **lineamientos claros** y define qué se espera de cada subordinado.
        
    - Incluye tareas como **planificación, organización, coordinación y control**.
        
4. **Liderazgo orientado al logro:**
    
    - Establece **metas desafiantes**.
        
    - Se enfoca en **mejorar el desempeño**.
        
    - Confía en que los subordinados **pueden alcanzar objetivos elevados**.

![[Pasted image 20250523020736.png]]



### **22. Propósito y Proceso de Comunicación**

#### **Propósito de la Comunicación en las Organizaciones**

La comunicación es un **proceso estratégico** que permite:

1. **Establecer y difundir metas**: Alinear objetivos organizacionales con los equipos.
    
2. **Planificar acciones**: Desarrollar planes operativos mediante información clara.
    
3. **Organizar recursos**: Coordinar personas, materiales y procesos de manera eficiente.
    
4. **Gestionar talento**: Evaluar y desarrollar colaboradores mediante feedback constante.
    
5. **Liderar y motivar**: Crear un clima laboral positivo que fomente la contribución.
    
6. **Controlar el desempeño**: Monitorear resultados y corregir desviaciones.
    

**Impacto**: Integra todas las funciones gerenciales (_planeación, organización, dirección, control_) y conecta a la empresa con su entorno (clientes, proveedores, gobierno).

![[Pasted image 20250523021308.png]]
#### **Proceso de Comunicación**

**Modelo Básico**:

1. **Emisor**: Genera una **idea** y la **codifica** (usa lenguaje, símbolos).
    
2. **Transmisión**: Envía el mensaje a través de un **canal** (email, reunión, etc.).
    
3. **Receptor**: **Recibe**, **decodifica** e **interpreta** el mensaje.
    
4. **Realimentación**: El receptor responde, cerrando el ciclo.
    

**Elementos clave**:

- **Ruido**: Interferencias (ej.: lenguaje técnico, distracciones).
    
- **Contexto**: Cultura organizacional, emociones y entorno.


![[Pasted image 20250523021415.png]]


#### **Proceso Comunicacional Interactivo e Intercultural**

**Factores que influyen**:

- **Cultura**: Diferencias generacionales, nacionales o de género.
    
- **Estado emocional**: Impacta en la codificación/decodificación.
    
- **Supuestos personales**: Percepciones previas que distorsionan el mensaje.
    

**Ejemplo**:  
Un gerente (_emisor_) de Argentina envía instrucciones a un equipo en Japón (_receptor_). Las diferencias culturales en jerarquía y comunicación no verbal pueden generar **ruido**, requiriendo ajustes en el lenguaje y medios (ej.: usar imágenes para clarificar).
![[Pasted image 20250523022021.png]]


#### **Relación con el Proceso Administrativo**

La comunicación es **transversal** a todas las etapas:

- **Planeación**: Transmite metas y estrategias.
    
- **Organización**: Coordina roles y responsabilidades.
    
- **Dirección**: Motiva y guía equipos.
    
- **Control**: Proporciona datos para evaluar resultados.
    

**Ejemplo práctico**:  
En un proyecto de software:

- **Planeación**: Reunión para definir objetivos (_comunicación descendente_).
    
- **Ejecución**: Feedback diario entre equipos (_comunicación horizontal_).
    
- **Control**: Reportes de avance a stakeholders (_comunicación ascendente_).
    
#### **Conclusión**

La comunicación efectiva es el **sistema nervioso** de una organización:

- **Propósito**: Alinear acciones hacia metas comunes.
    
- **Proceso**: Requiere claridad, adaptación cultural y canales adecuados.
    
- **Integración**: Conecta todas las funciones administrativas y stakeholders

### **23. El Flujo de la Comunicación en la Organización**

#### **Tipos de Flujos Comunicacionales**

En las organizaciones, la comunicación fluye en **cuatro direcciones principales**, cada una con funciones específicas:

1. **Comunicación Descendente**
    
    - **Definición**: Fluye desde los niveles superiores (gerencia) hacia los inferiores (empleados).
        
    - **Propósito**:
        
        - Transmitir metas, políticas y directrices.
            
        - Delegar tareas y responsabilidades.
            
        - Proporcionar feedback sobre desempeño.
            
    - **Ejemplo**: Un jefe envía un correo con los objetivos trimestrales a su equipo.
        
2. **Comunicación Ascendente**
    
    - **Definición**: Viaja desde los subordinados hacia los superiores.
        
    - **Propósito**:
        
        - Reportar problemas o sugerencias.
            
        - Informar sobre progresos o obstáculos.
            
        - Fomentar la participación y el empoderamiento.
            
    - **Ejemplo**: Un empleado envía un informe de avance a su gerente.
        
3. **Comunicación Horizontal**
    
    - **Definición**: Ocurre entre personas del **mismo nivel jerárquico**.
        
    - **Propósito**:
        
        - Coordinar tareas entre departamentos.
            
        - Resolver conflictos interáreas.
            
        - Promover la colaboración.
            
    - **Ejemplo**: Reunión entre los equipos de marketing y ventas para alinear estrategias.
        
4. **Comunicación Diagonal (Cruzada)**
    
    - **Definición**: Intercambio entre personas de **diferentes niveles y áreas sin relación directa de reporte**.
        
    - **Propósito**:
        
        - Agilizar procesos en estructuras complejas.
            
        - Facilitar la innovación mediante interacciones multidisciplinarias.
            
    - **Ejemplo**: Un analista de datos se comunica con un director de otro departamento para compartir insights.
        
#### **Importancia de la Comunicación Cruzada**

- **Ventajas**:
    
    - Rompe silos organizacionales.
        
    - Acelera la toma de decisiones.
        
    - Fomenta la creatividad mediante perspectivas diversas.
        
- **Riesgos**:
    
    - Puede generar confusión en las líneas de autoridad.
        
    - Requiere claridad para evitar duplicación de esfuerzos.

![[Pasted image 20250523022824.png]]

### **24. Barreras e Interrupciones en la Comunicación**

#### **Clasificación de las Barreras**

Las barreras comunicacionales pueden originarse en el **emisor, el mensaje, el receptor o el contexto**, y se dividen en:

### **I. Barreras Internas (Organizacionales)**

1. **Falta de planeación**
    
    - Comunicar sin definir objetivos claros o seleccionar el canal adecuado.
        
    - _Ejemplo_: Un gerente envía instrucciones ambiguas por email sin especificar plazos.
        
2. **Supuestos no aclarados**
    
    - Expectativas implícitas no comunicadas.
        
    - _Ejemplo_: Un cliente asume que su proveedor organizará logística sin solicitarlo explícitamente.
        
3. **Distorsión semántica**
    
    - Uso de lenguaje ambiguo, técnico o culturalmente inapropiado.
        
    - _Ejemplo_: El eslogan _"Put a Tiger in Your Tank"_ de Exxon fue ofensivo en Tailandia.
        
4. **Pérdidas en la transmisión**
    
    - Degradación del mensaje en cadenas largas de comunicación.
        
    - _Ejemplo_: El "teléfono descompuesto" en jerarquías organizacionales rígidas.
        
5. **Atención deficiente y evaluación prematura**
    
    - Receptor que no escucha activamente o juzga antes de comprender.
        
    - _Ejemplo_: Un empleado interrumpe a su colega para imponer su opinión.
        
6. **Sobrecarga de información**
    
    - Exceso de datos que satura al receptor.
        
    - _Respuestas comunes_:
        
        - Ignorar información relevante.
            
        - Cometer errores al procesar (ej.: omitir un "no" en un mensaje).
            
        - Filtrar prioridades de manera ineficaz.
            
7. **Comunicación impersonal**
    
    - Abuso de medios digitales en lugar de interacción cara a cara.
        
    - _Ejemplo_: Enviar un despido por correo electrónico en lugar de una reunión.
        
8. **Desconfianza, amenaza y temor**
    
    - Clima laboral tóxico que inhibe la transparencia.
        
    - _Ejemplo_: Empleados ocultan errores por miedo a represalias.
        
9. **Resistencia al cambio**
    
    - Falta de tiempo para adaptarse a nuevas directivas.
        
    - _Ejemplo_: Implementar un nuevo software sin capacitación previa.
        

### **II. Barreras Externas (Interculturales)**

1. **Diferencias de lenguaje**
    
    - Traducciones literales que generan malentendidos.
        
    - _Ejemplo_: Pepsi's _"Come Alive with the Pepsi Generation"_ se tradujo en China como _"Pepsi revive a tus ancestros"_.
        
2. **Normas culturales**
    
    - Gestos, colores o formalidades con significados opuestos.
        
    - _Ejemplo_:
        
        - **Negro** (luto en Occidente vs. elegancia en Oriente).
            
        - **Tuteo** (común en EE.UU., pero irrespetuoso en Japón).
            
3. **Jerarquías sociales**
    
    - Estructuras de poder que limitan la comunicación ascendente.
        
    - _Ejemplo_: En culturas altamente jerárquicas (ej.: Corea), los subordinados evitan contradecir a sus superiores.
        
### **III. Barreras Psicológicas**

1. **Percepción selectiva**
    
    - Filtrar información según prejuicios o intereses.
        
    - _Ejemplo_: Un equipo ignora feedback negativo por considerar que "ya lo sabe todo".
        
2. **Actitudes preestablecidas**
    
    - Mentalidad cerrada que bloquea nuevos mensajes.
        
    - _Ejemplo_: Rechazar ideas innovadoras por apego a métodos tradicionales.
        
3. **Diferencias de estatus**
    
    - Asimetría de poder que distorsiona la comunicación.
        
    - _Ejemplo_: Un empleado modifica sus informes para agradar a su jefe.
        

### **Consecuencias de las Barreras**

- **Operativas**: Errores en la ejecución de tareas.
    
- **Estratégicas**: Desalineación con los objetivos organizacionales.
    
- **Humanas**: Baja moral, rotación de personal y conflictos.
###  **Conclusión:**

Las barreras a la comunicación son múltiples y pueden ser sutiles o evidentes. Un gerente eficaz no solo se enfoca en los síntomas, sino que investiga las causas de fondo y aplica estrategias para minimizarlas, creando un entorno basado en la **claridad, empatía, confianza y retroalimentación continua**.

### **25. Describa los elementos necesarios para una comunicación efectiva**

La **comunicación efectiva** no ocurre por casualidad, sino que requiere planeación, empatía y claridad en cada paso del proceso. Implica tanto la **responsabilidad del emisor** como del **receptor**, con el fin de lograr una verdadera comprensión del mensaje y generar una acción adecuada.

### **Elementos clave para una comunicación efectiva:**

#### 1. **Aclarar el propósito del mensaje**

Antes de comunicar, el emisor debe tener claro **qué desea comunicar** y **con qué objetivo**. Un mensaje con propósito definido es más comprensible, persuasivo y menos propenso a generar confusión.

#### 2. **Usar una codificación inteligible**

La información debe estar formulada con **símbolos y lenguaje que el receptor comprenda**. Evitar tecnicismos innecesarios ayuda a que el mensaje sea accesible y significativo para todos los destinatarios, no solo para expertos.

#### 3. **Consultar los puntos de vista de los demás**

Incluir a otros en la planificación de la comunicación (por ejemplo, revisando un memo o presentando distintas perspectivas) mejora la calidad del mensaje, asegura su pertinencia y lo adapta al **nivel de conocimiento y contexto del receptor**.

#### 4. **Considerar las necesidades del receptor**

El mensaje debe aportar **valor** a quien lo recibe. A veces, incluso **comunicaciones impopulares** pueden ser aceptadas si se explican **los beneficios a largo plazo**, como en el caso de una reducción de la jornada para evitar despidos.

#### 5. **Utilizar tono y lenguaje apropiados**

El **cómo se dice** algo influye tanto como **lo que se dice**. Un tono congruente, respetuoso y adaptado a la situación genera credibilidad. Por ejemplo, un líder que impone sin coherencia entre palabras y acciones pierde confianza.

#### 6. **Obtener retroalimentación**

La comunicación se completa **solo cuando el receptor comprende el mensaje**. Para asegurarlo, se necesita **retroalimentación**, que puede ser preguntas, respuestas, comentarios o reacciones del receptor al mensaje.

#### 7. **Considerar emociones y motivaciones**

La comunicación trata también con **emociones humanas**. Crear un ambiente donde las personas se sientan escuchadas y motivadas impulsa tanto el logro de **objetivos personales** como **organizacionales**. Además, la comunicación efectiva es esencial para fomentar el **autocontrol**, tal como lo promueve la filosofía de Administración por Objetivos (APO).

#### 8. **Escuchar activamente**

La escucha es tan importante como el habla. El receptor debe:

- Prestar atención total.
    
- Escuchar sin juzgar anticipadamente.
    
- Evitar interrupciones.
    
- Buscar comprender el marco de referencia del emisor.
    

Escuchar con empatía mejora las relaciones interpersonales y la eficacia general de la organización.
### **Conclusión:**

Una comunicación efectiva se basa en **propósito, claridad, adaptación, retroalimentación y empatía**. Es una herramienta fundamental en la dirección organizacional y requiere esfuerzo tanto del emisor como del receptor para ser verdaderamente significativa.

# TPN°6 - Control
## Control
El **control** es una de las funciones principales de la administración y consiste en **medir y corregir el desempeño** para asegurarse de que los **objetivos y planes** de una organización se estén cumpliendo correctamente.

En otras palabras, el control verifica si lo que se está haciendo va en la dirección correcta, compara lo planeado con lo que realmente sucede, y toma medidas si hay desviaciones.

### En resumen:

> **Control = Medir + Comparar + Corregir**

Y depende directamente de tener **objetivos claros y planes definidos**, ya que sin ellos no habría con qué comparar el desempeño.

Definicion 2:
- La función gerencial de **control** es la **medición y corrección del desempeño** para garantizar que los objetivos de la empresa y los planes diseñados para alcanzarlos se logren, y se relaciona estrechamente con la función de **planear**. De hecho, algunos autores sobre administración consideran que estas funciones no pueden separarse, aunque es sensato distinguirlas conceptualmente.
    
- Sin objetivos y planes, el control no es posible, porque el desempeño debe medirse frente a los criterios establecidos.

## 1. Proceso de control básico

Las **técnicas y los sistemas de control** son en esencia los mismos para controlar el efectivo, los procedimientos administrativos, la ética organizacional, la calidad del producto y cualquier otra cosa.

El **proceso de control básico**, en cualquier lugar y para lo que sea que se controle, incluye tres pasos:

1. **Establecer estándares**: Se definen criterios de desempeño basados en los planes de la organización. Estos estándares pueden ser físicos, de costos, de capital, de ingresos, entre otros.
    
2. **Medir el desempeño**: Se compara el desempeño real con los estándares establecidos. Esto puede hacerse de manera anticipada para prevenir desviaciones.
    
3. **Corregir desviaciones**: Se implementan acciones correctivas para alinear el desempeño con los estándares. Esto puede implicar ajustes en los planes, reorganización de tareas, capacitación del personal o cambios en la dirección.
### Proceso de control básico
Las técnicas y los sistemas de control son en esencia los mismos para controlar el efectivo, los
procedimientos administrativos, la ética organizacional, la calidad del producto y cualquier otra
cosa. El proceso de control básico, en cualquier lugar y para lo que sea que se controle, incluye
tres pasos:
4. Establecer estándares.
5. Medir el desempeño contra estos estándares.
6. Corregir las variaciones de los estándares y planes.

Estándares Criterios de desempeño.

1. **Establecimiento de estándares**  
    El primer paso del control es establecer **criterios de desempeño** (estándares), basados en los planes. Estos estándares permiten a los administradores saber cómo van las cosas sin tener que vigilar cada detalle. Los mejores estándares son **metas u objetivos verificables**.
    
2. **Medición del desempeño**  
    Se debe medir el desempeño frente a los estándares, preferiblemente **de forma anticipada**, para detectar posibles desviaciones a tiempo y corregirlas antes de que ocurran. Los administradores con visión pueden incluso predecir estas desviaciones.
    
3. **Corrección de desviaciones**  
    Si se detectan desviaciones, los administradores deben tomar **acciones correctivas**. Estas pueden incluir:
    

- Modificar planes o metas.
    
- Reasignar o aclarar tareas.
    
- Asignar más personal, mejorar la selección o capacitación.
    
- Como último recurso, **reajustar personal** (despidos).
    
- Mejorar la dirección a través de una mayor explicación de las tareas o aplicar técnicas de liderazgo más efectivas.
    

La corrección de desviaciones conecta el control con todas las demás **funciones gerenciales** (planificación, organización, dirección).


## 2. Puntos de control clave, estándares y benchmarking

### Puntos de control clave

- Los **puntos seleccionados para el control** deben ser **clave**, en el sentido de ser **factores limitantes** para la operación o mejores indicadores que otros factores respecto de si los planes están funcionando.
    
- Con tales estándares, los administradores pueden manejar un grupo mayor de subordinados y así **aumentar su ámbito de administración**, con los resultantes **ahorros en costos** y la **mejoría de la comunicación**.
    
- El **principio de control de puntos clave**, uno de los más importantes, establece que el control efectivo requiere de la atención de **aquellos factores decisivos** para evaluar el desempeño en relación con los planes.
    
- Otra forma de control es comparar el desempeño de la compañía con el de otras a partir de los **puntos de referencia** o **benchmarking**.

### Tipos de estándares de puntos clave

Cada objetivo, cada meta de los programas de planeación, cada actividad de estos programas, cada política, cada procedimiento y cada presupuesto pueden convertirse en un **estándar** respecto del cual podría medirse el desempeño real o esperado.

En la práctica, los estándares tienden a ser de los siguientes tipos:

1. **Físicos**
    
2. **De costos**
    
3. **De capital**
    
4. **De ingresos**
    
5. **De programas**
    
6. **Intangibles**
    
7. **De metas**
    
8. **Planes estratégicos** como puntos para el control estratégico

## Resumen — Tipos de estándares de puntos clave

### 1. **Estándares físicos**

Son **medidas no monetarias**, comunes en el nivel operativo. Reflejan:

- **Cantidades**: horas de mano de obra por unidad, litros de combustible, unidades de producción, etc.
    
- **Calidad**: rigidez de componentes, tolerancias, durabilidad, etc.
    

### 2. **Estándares de costos**

Son **medidas monetarias** aplicadas a operaciones. Ejemplos:

- Costos directos e indirectos por unidad producida.
    
- Costo de mano de obra, materiales, máquinas, ventas, etc.
    

### 3. **Estándares de capital**

Relacionados con el **capital invertido** y el balance general. Ejemplos:

- Rendimiento sobre la inversión.
    
- Relación activos/pasivos, deuda/valor neto, rotación de inventarios, etc.
    

### 4. **Estándares de ingresos**

Valores monetarios asignados a las **ventas**. Ejemplos:

- Ingresos por pasajero/km.
    
- Ventas promedio por cliente.
    
- Ventas per cápita en un área.
    

### 5. **Estándares de programas**

Se aplican al desempeño en la **implementación de programas**. Ejemplos:

- Instalación de un presupuesto variable.
    
- Seguimiento de desarrollo de productos.
    
- Mejora de la fuerza de ventas.  
    Pueden tener componentes subjetivos y objetivos (plazos, cumplimiento, etc.).
    

### 6. **Estándares intangibles**

Más difíciles de cuantificar. Ejemplos:

- Competencia del personal.
    
- Éxito de un programa de publicidad o relaciones públicas.
    
- Lealtad de los supervisores.  
    Requieren evaluación cualitativa.
    

### 7. **Estándares de metas**

Tendencia actual: definir metas **cuantitativas y cualitativas verificables**.  
Ejemplos:

- Capacitación del personal según estándares definidos.
    
- Programas complejos que incluyen objetivos tangibles y medibles.
    

### 8. **Planes estratégicos como puntos de verificación del control estratégico**

El **control estratégico** implica:

- Monitoreo sistemático de **puntos estratégicos**.
    
- Modificación de la estrategia con base en la evaluación.  
    El control facilita la comparación entre metas y desempeño, genera oportunidades de **aprendizaje** y permite la adaptación al entorno cambiante.



**Puntos de referencia (benchmarking)**

- Benchmarking es un concepto que hoy tiene amplia aceptación, se trata de un enfoque para establecer metas y medidas de productividad con base en las mejores prácticas de la industria y que se desarrolló a partir de la necesidad de tener datos frente a los cuales medir el desempeño.
    
- ¿Cuáles deben ser los criterios? Si una compañía requiere seis días para surtir el pedido de un cliente y un competidor en la misma industria sólo cinco, estos últimos no se convierten en el estándar si existe una empresa en una industria no relacionada que puede surtir pedidos en cuatro días.

- El criterio de cuatro días se convierte en el punto de referencia aun cuando en principio parezca una meta inalcanzable, luego se analiza con cuidado el proceso involucrado para surtir un pedido y se fomentan modos creativos para alcanzar ese punto de referencia.
    

**Tipos de puntos de referencia:**

1. El benchmarking estratégico compara varias estrategias e identifica los elementos estratégicos clave para el éxito.
    
2. El benchmarking operacional compara costos relativos o posibilidades de diferenciación de productos.
    
3. El benchmarking administrativo se enfoca a funciones de apoyo, como la planeación de mercados y los sistemas de información, la logística, la administración de recursos humanos, etcétera.


**Procedimiento de puntos de referencia:**

- El procedimiento de puntos de referencia empieza con la identificación de lo que debe compararse, y luego se selecciona a quienes tienen un desempeño superior.
    
- Se requiere recopilar y analizar datos, que se convierten en la base de las metas de desempeño. Durante la instrumentación del nuevo enfoque, el desempeño se mide periódicamente y en ese momento se adoptan medidas correctivas

Def:2
### **Tipos de benchmarking**

1. **Estratégico:** compara estrategias e identifica elementos clave para el éxito.
    
2. **Operacional:** compara **costos relativos** o **diferenciación de productos**.
    
3. **Administrativo:** compara funciones de apoyo como:
    
    - Planeación de mercados
        
    - Sistemas de información
        
    - Logística
        
    - Recursos humanos, etc.
        

### **Procedimiento**

1. Identificar **qué se debe comparar**.
    
2. Seleccionar **referentes superiores**.
    
3. **Recopilar y analizar datos** para establecer metas.
    
4. Medir el desempeño de forma **periódica**.
    
5. Aplicar **medidas correctivas** cuando sea necesario.

#### forma corta:
## 2. Puntos de control clave, estándares y benchmarking

### Puntos de control clave

Son factores críticos que permiten evaluar el desempeño de manera eficiente. Estos puntos deben ser seleccionados cuidadosamente para que sean representativos del funcionamiento general de la organización. Ejemplos incluyen estándares de calidad, costos unitarios o tiempos de entrega.

### Tipos de estándares

1. **Físicos**: Relacionados con cantidades o unidades tangibles.
    
2. **De costos**: Basados en gastos o inversiones.
    
3. **De capital**: Enfocados en recursos financieros.
    
4. **De ingresos**: Relacionados con ventas o ganancias.
    
5. **De programas**: Para proyectos o actividades específicas.
    
6. **Intangibles**: Como la satisfacción del cliente o la reputación.
    

### Benchmarking

Es un enfoque para establecer metas basadas en las mejores prácticas de la industria. Se divide en tres tipos:

1. **Estratégico**: Compara estrategias clave para el éxito.
    
2. **Operacional**: Analiza costos y diferenciación de productos.
    
3. **Administrativo**: Evalúa funciones de apoyo como logística o recursos humanos.
    

El proceso de benchmarking implica identificar áreas de mejora, seleccionar referentes, recopilar datos y aplicar cambios para alcanzar los estándares deseados.

## 4. Control preventivo o anticipativo
El control preventivo se enfoca en anticipar problemas antes de que ocurran, en lugar de corregirlos después. Utiliza sistemas de información que monitorean los insumos de un proceso para asegurar que cumplan con lo planeado. Si se detectan desviaciones, se toman medidas correctivas de manera proactiva.

**Requisitos para un sistema de corrección anticipativa**:

1. Análisis detallado de las variables clave del sistema.
    
2. Desarrollo de un modelo actualizado del proceso.
    
3. Recopilación regular de datos sobre los insumos.
    
4. Evaluación de desviaciones y sus efectos en los resultados.
    
5. Implementación de acciones correctivas.

forma extensa:
## Control preventivo o anticipativo
- La demora en el proceso de control administrativo muestra que, para que el control sea efectivo, debe enfocarse en el futuro. Pone de manifiesto el problema de utilizar sólo la realimentación de los resultados de un sistema y su medición como medio de control, muestra la deficiencia de los datos históricos, como los que se reciben de los reportes de contabilidad.
    
- Una de las dificultades de los datos históricos es que, por ejemplo, dicen a los administradores en noviembre que perdieron dinero en octubre (o hasta en septiembre) por algo que se hizo en julio: en el momento en que se conoce, esa información es sólo un hecho histórico interesante y angustiante.

- En la práctica se ignora el control dirigido hacia el futuro, sobre todo porque los administradores dependen mucho de los datos contables y estadísticos para propósitos de control.
    
- Se puede estar seguro de que en ausencia de cualquier medio de previsión a futuro, la referencia a la historia (sobre el cuestionable supuesto de que lo que ocurrió en el pasado es un prólogo) se admite mejor que ninguna referencia.
![[Pasted image 20250606080336.png]]

**Para un control efectivo, los administradores requieren un sistema de corrección anticipativo que les informe sobre los problemas potenciales y permita tomar las medidas correctivas antes de que surjan esos problemas.**

**Sistemas de información correctiva y anticipativa Monitorean los insumos de un proceso para asegurar si son los planeados; si no es así, éstos, o quizás el proceso, se modifican para obtener los resultados deseados.**

**Requisitos del sistema de corrección anticipativa**

1. Hacer un completo y cuidadoso análisis del sistema de planeación y control e identificar las variables de insumos más importantes.
    
2. Desarrollar un modelo del sistema.
    
3. Tener cuidado de mantener el modelo actualizado; en otras palabras, éste debe revisarse con regularidad para ver si las variables de insumos identificadas y sus interrelaciones siguen representando realidades.
    
4. Recopilar datos sobre las variables de insumos con regularidad e introducirlos al sistema.
    
5. Evaluar con regularidad las variaciones de los datos de insumos reales con respecto a los insumos planeados, y evaluar el efecto en el resultado final esperado.
    
6. Tomar medidas; como cualquier otra técnica de planeación y control, todo lo que el sistema puede hacer es indicar problemas: es evidente que las personas deben realizar acciones para resolverlos.

Detalle:
**Control Preventivo:**  
Es un tipo de control que se enfoca en anticipar y evitar problemas antes de que ocurran. Su objetivo es detectar posibles desviaciones o fallas en los procesos a tiempo para tomar medidas correctivas que eviten que esos problemas afecten los resultados finales. Este control se basa en la supervisión y revisión continua de los insumos y procedimientos para garantizar que todo funcione según lo planeado.

**Control Anticipativo:**  
Es un sistema que proporciona información temprana sobre posibles problemas futuros, permitiendo que los administradores actúen con anticipación. Va más allá del control preventivo al integrar sistemas de información que monitorean constantemente los insumos y procesos, y que facilitan la toma de decisiones correctivas antes de que las desviaciones ocurran realmente. Este control es clave para mantener la eficiencia y eficacia operativa, ya que permite corregir el rumbo a tiempo.

## 5. Requisitos para controles efectivos

1. **Adaptación a planes y puestos**: Los controles deben reflejar los objetivos específicos de cada área.
    
2. **Comprensibilidad**: Los sistemas de control deben ser entendibles para los gerentes que los utilizan.
    
3. **Enfoque en excepciones y puntos clave**: Concentrarse en áreas críticas y desviaciones significativas.
    
4. **Objetividad**: Los estándares deben ser precisos y medibles.
    
5. **Flexibilidad**: Los controles deben adaptarse a cambios en los planes o circunstancias.
    
6. **Alineación con la cultura organizacional**: El sistema de control debe ser compatible con los valores y prácticas de la empresa.
forma Extensa:
**CONTROL — Requisitos de los controles efectivos**

- **Adaptar los controles a los planes y puestos**  
    Todas las técnicas y los sistemas de control deben reflejar los planes para los que fueron diseñados y adaptarse a los puestos: lo que sería apropiado para un vicepresidente a cargo de la manufactura ciertamente no será adecuado para un supervisor de taller.
    
- **Adaptar los controles a cada administrador**  
    Los sistemas de control e información, por supuesto, tienen el propósito de ayudar a cada uno a desarrollar su función de control; si son del tipo que un gerente no pueda comprender, no le serán útiles. Los individuos no confían en lo que no pueden comprender y no utilizan aquello en lo que no confían.
    
- **Diseñar controles para señalar excepciones en puntos clave**  
    En la práctica, el principio de excepción debería ir acompañado por el principio del punto de control clave. No es suficiente conformarse con sólo buscar excepciones: deben buscarse en puntos clave. Por supuesto que cuanto más concentren los gerentes sus esfuerzos en las excepciones, más eficiente será su control; pero el control efectivo requiere que también presten atención primaria a las cosas que son más importantes.
    
- **Objetividad de los controles**  
    El control efectivo requiere estándares objetivos, precisos y adecuados. McDonald’s, por ejemplo, es muy estricto al aplicar y mantener los mismos estándares de calidad en todos sus restaurantes.
    
- **Asegurar la flexibilidad de los controles**  
    Los controles deben continuar siendo funcionales ante los cambios de planes, las circunstancias imprevistas o los fracasos rotundos; asimismo, para que sigan siendo efectivos, a pesar de un fracaso o de cambios inesperados en los planes, deben ser flexibles.
    
- **Ajustar el sistema de control a la cultura de la organización**  
    Para ser más efectivo, cualquier sistema o técnica de control debe ajustarse a la cultura de la organización: si una empresa ha dado a sus empleados bastante libertad y participación, un sistema de control estricto puede ir tan a contracorriente que estará destinado al fracaso; en cambio, si los subordinados tienen un superior que casi no les permite tomar decisiones, un sistema de control generalizado y permisivo tendrá pocas probabilidades de éxito.

forma rapida:
### Requisitos de los controles efectivos (versión breve)

 **Adaptar a planes y puestos:** controles adecuados al nivel y función de cada puesto.

 **Adaptar a cada administrador:** controles comprensibles y confiables para cada gerente.

 **Señalar excepciones en puntos clave:** enfocarse en las desviaciones más importantes.

 **Objetividad:** estándares objetivos y precisos, aceptados por todos.

 **Flexibilidad:** controles que se mantengan útiles ante cambios y situaciones imprevistas.

 **Ajuste a la cultura:** controles coherentes con la cultura y estilo de gestión de la organización.


### **7. Describa el presupuesto como dispositivo de control.**

El **presupuesto** es una herramienta clave del control administrativo que establece límites financieros sobre el uso de recursos. Actúa como estándar contra el cual se puede comparar el desempeño real, permitiendo identificar desviaciones y tomar decisiones correctivas. También es útil para coordinar las actividades entre departamentos y evaluar la eficiencia de los mismos.

#### Presupuesto como dispositivo de control
Un dispositivo muy usado para el control gerencial es el presupuesto, de hecho, en ocasiones se
ha asumido que la asignación de presupuestos es el dispositivo para lograr el control; sin embargo,
muchos dispositivos no presupuestales también son esenciales.
#### Concepto de asignación de presupuestos
La asignación de presupuestos es la formulación de planes en términos numéricos
para un periodo futuro determinado; como tal, los presupuestos son declaraciones
anticipadas de resultados, ya sea en términos financieros (ingresos y gastos, así
como presupuestos de capital) o no financieros (presupuestos de horas de mano de
obra directa, materiales, volumen de ventas físicas o unidades de producción), en
ocasiones se ha dicho, por ejemplo, que los presupuestos financieros representan la
dolarización de los planes.

## 8. Describa y grafique el análisis de red tiempo-suceso.
El análisis de red tiempo-suceso es una técnica que permite planificar y controlar proyectos complejos. Se representa mediante un diagrama de red que muestra:

- **Eventos**: Puntos clave del proyecto.
    
- **Actividades**: Tareas necesarias para alcanzar los eventos.
    
- **Tiempos**: Duración estimada de cada actividad.
**Suceso**  
Plan de soporte cuya terminación puede medirse en un momento determinado.

**Actividad**  
Elemento que consume tiempo de un programa o el esfuerzo que debe realizarse entre sucesos.

**Tiempo de actividad**  
Es el tiempo requerido para completar un suceso, representado por los números al lado de las flechas.
![[Pasted image 20250606095218.png]]
![[Pasted image 20250606095241.png]]


### PERT — Técnica de evaluación y revisión de programas

- Desarrollada por la Marina de EE. UU. en 1958 para planear y controlar el proyecto del Sistema de Armas Polaris.
    
- Muy utilizada en proyectos militares y espaciales, y actualmente también en construcción, ingeniería, generación de reportes financieros, entre otros.
    

#### **Características principales:**

- Es un sistema de **análisis de red de tiempo-suceso**.
    
- Identifica los **sucesos** (eventos medibles) de un proyecto y establece un tiempo para cada uno.
    
- Los sucesos se representan en una **red** que muestra las relaciones entre ellos.
    
- Los **círculos** en el diagrama representan sucesos; las **flechas** representan **actividades** (acciones que consumen tiempo entre sucesos).
    
- El tiempo de actividad se indica junto a las flechas.
    
- Se utiliza para planear, controlar y agilizar proyectos complejos.

definicion mas completa:
###  **Descripción del análisis de red tiempo-suceso (PERT)**

El análisis de red tiempo-suceso es una técnica de planeación y control de proyectos complejos, utilizada para identificar la secuencia óptima de tareas y el tiempo total requerido para completar un proyecto.  
Fue desarrollada originalmente en 1958 por la Marina de los Estados Unidos para el programa Polaris y desde entonces se ha aplicado en múltiples áreas, como ingeniería, construcción, y gestión de proyectos.

#### **Elementos básicos:**

- **Suceso:**  
    Punto de referencia cuya terminación puede medirse en un momento determinado. Se representa como un **círculo** en la red.
    
- **Actividad:**  
    Elemento que consume tiempo de un programa o esfuerzo que debe realizarse entre dos sucesos. Se representa con una **flecha** que conecta dos sucesos.
    
- **Tiempo de actividad:**  
    Tiempo requerido para completar una actividad, indicado en la flecha.
    

#### **Estimaciones de tiempo:**

Cada actividad puede tener tres estimaciones de tiempo:

1. **Optimista:** Tiempo mínimo si todo sale excepcionalmente bien.
    
2. **Más probable:** Estimado realista según la experiencia.
    
3. **Pesimista:** Tiempo considerando posibles problemas o demoras.
    

En el ejemplo mostrado, se utiliza un solo tiempo (probablemente una media ponderada de los tres estimados).

#### **Ruta crítica:**

- Es la **secuencia de sucesos** que determina la duración total del proyecto.
    
- Es la ruta más larga de la red, sin tiempos muertos o con tiempos muertos mínimos.
    
- Si una actividad en la ruta crítica se retrasa, todo el proyecto se retrasa.
    
- Permite a los administradores enfocar sus esfuerzos en las actividades que más afectan el cronograma.
    

###  **Fortalezas del análisis PERT:**

1. Obliga a los administradores a planear detalladamente el proyecto.
    
2. Promueve la planeación participativa desde los niveles inferiores.
    
3. Resalta elementos clave que requieren atención.
    
4. Facilita un control anticipado para mitigar retrasos.
    
5. Mejora la asignación de responsabilidades y permite un seguimiento adecuado.
    

###  **Debilidades del análisis PERT:**

- Depende de la precisión en la estimación de tiempos.
    
- Se enfoca principalmente en el tiempo, no en los costos (aunque existe PERT/costo para esto).
    
- Es difícil de manejar manualmente en proyectos con más de 200–300 sucesos, requiriendo el uso de computadoras.

## 9. Cuadro de Mando Integral (Balanced Scorecard)
El **cuadro de mando integral** (o _balanced scorecard_) es una herramienta administrativa que ayuda a asegurar el alineamiento de los objetivos estratégicos de una compañía con sus actividades operacionales; por tanto, este enfoque es complementario a las herramientas de planeación estratégica que se concentran en desarrollar objetivos de alto nivel.

En concreto, el cuadro de mando integral ayuda a las organizaciones a desarrollar una visión exhaustiva de sus negocios y medidas operacionales de éxito que, si se atienden, las ayudarán a alcanzar sus metas estratégicas y el desempeño financiero deseado.

Estas medidas y puntos de vista son cualitativos y cuantitativos, desde una perspectiva interna y externa, y son los que proveen el balance del desempeño y las medidas de administración y estratégicas.
![[Pasted image 20250606100924.png]]

forma resumida:
El Cuadro de Mando Integral es una herramienta estratégica que alinea los objetivos de la organización con medidas operativas. Incluye cuatro perspectivas:

1. **Financiera**: Metas relacionadas con rentabilidad y costos.
    
2. **Cliente**: Enfoque en satisfacción y lealtad del cliente.
    
3. **Procesos internos**: Mejora de eficiencia y calidad.
    
4. **Aprendizaje y crecimiento**: Desarrollo de capacidades organizacionales.

## 15. Herramientas y técnicas para mejorar la productividad

Existen muchas herramientas y técnicas disponibles para mejorar las operaciones de manufactura y servicios. Entre ellas se destacan:

1. **Planeación y control de inventarios**
    
2. **Sistema de inventarios Justo a Tiempo (JIT)**
    
3. **Contratación externa (outsourcing)**
    
4. **Investigación de operaciones**
    
5. **Ingeniería de valor**
    
6. **Simplificación del trabajo**
    
7. **Círculos de calidad**
    
8. **Administración de la calidad total (TQM)**
    
9. **Manufactura esbelta (Lean Manufacturing)**
    
10. **Diseño y manufactura asistidos por computadora (CAD/CAM)**

### 1. Planeación y control de inventarios

Permite determinar los niveles óptimos de inventario para satisfacer la demanda minimizando costos. Se basa en modelos como la Cantidad Económica de Pedido (CEP) y en sistemas avanzados que integran producción, distribución y finanzas.

### 2. Sistema de inventarios Justo a Tiempo (JIT)

Método en el que los insumos llegan justo cuando se necesitan en el proceso productivo, reduciendo inventarios y costos. Requiere alta calidad, relaciones confiables con proveedores y cercanía geográfica.

### 3. Contratación externa (outsourcing)

Práctica de delegar la producción de bienes o servicios a proveedores especializados externos. Permite concentrarse en competencias clave, aunque puede presentar desafíos logísticos y de control de calidad.

### 4. Investigación de operaciones

Aplicación del método científico y el análisis cuantitativo para evaluar alternativas y optimizar la toma de decisiones en problemas complejos de operaciones.

### 5. Ingeniería de valor

Proceso que busca mejorar productos o servicios reduciendo costos sin afectar su calidad, mediante el análisis detallado de cada componente y operación.

### 6. Simplificación del trabajo

Técnica participativa en la que los trabajadores colaboran para simplificar procesos laborales, utilizando herramientas como estudios de tiempos y análisis de flujo de trabajo.

### 7. Círculos de calidad

Grupos de empleados que se reúnen regularmente para identificar y resolver problemas relacionados con su trabajo, promoviendo la mejora continua y la participación.

### 8. Administración de la calidad total (TQM)

Enfoque integral que promueve la mejora continua de la calidad en toda la organización, con participación activa de todos los niveles y con el objetivo de satisfacer y superar las expectativas del cliente.

### 9. Manufactura esbelta (Lean Manufacturing)

Sistema de producción que busca maximizar el valor para el cliente eliminando desperdicios, optimizando recursos y agilizando los procesos.

### 10. Diseño y manufactura asistidos por computadora (CAD/CAM)

Uso de tecnologías digitales para diseñar productos (CAD) y controlar procesos de manufactura (CAM), mejorando la velocidad, precisión y flexibilidad en el desarrollo de productos.

### DEFINICION 2:
### 1. Planeación y control de inventarios

Proceso que permite determinar los niveles óptimos de inventario para satisfacer la demanda, minimizando costos de mantenimiento, pedidos y escasez.

### 2. Sistema de inventario Justo a Tiempo (JIT)

El proveedor entrega los componentes y las partes a la línea de producción sólo cuando son necesarios y justo a tiempo para ser ensamblados.

### 3. Contratación externa (outsourcing)

Contratación de la producción y las operaciones con proveedores externos que tienen experiencia en áreas específicas.

### 4. Investigación de operaciones

Aplicación de métodos científicos al estudio de alternativas en una situación problema, con la visión de obtener una base cuantitativa para llegar a la mejor solución.

### 5. Ingeniería de valor

Proceso mediante el que se analizan las operaciones de un producto o servicio, se estima el valor de cada operación y se intenta mejorarla al tratar de mantener bajos los costos en cada paso o parte.

### 6. Simplificación del trabajo

Proceso mediante el que los trabajadores participan para simplificar su trabajo, mejorando métodos y eliminando actividades innecesarias.

### 7. Círculo de calidad

Grupo de personas de la misma área de la organización que se reúne con regularidad para resolver los problemas que experimentan en el trabajo.

### 8. Administración de la calidad total (TQM)

Compromiso a largo plazo de tender a la mejora continua de la calidad, en toda la organización y con la participación activa de los miembros de todos los niveles, para cumplir y exceder las expectativas de los clientes.

### 9. Manufactura esbelta (Lean Manufacturing)

Sistema de producción que busca maximizar el valor para el cliente eliminando desperdicios, optimizando recursos y agilizando los procesos.

### 10. Diseño y manufactura asistidos por computadora (CAD/CAM)

Uso de tecnologías de computación para diseñar productos (CAD) y controlar procesos de manufactura (CAM), mejorando la precisión, la velocidad y la flexibilidad.


